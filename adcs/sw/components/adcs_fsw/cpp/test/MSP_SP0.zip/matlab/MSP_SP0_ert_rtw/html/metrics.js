function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	size: 104};
	 this.metricsArray.var["rtM_"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	size: 4};
	 this.metricsArray.var["rtU"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	size: 60};
	 this.metricsArray.var["rtY"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	size: 48};
	 this.metricsArray.fcn["MSP_SP0_initialize"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MSP_SP0_step0"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MSP_SP0_step1"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 14,
	stackTotal: 14};
	 this.metricsArray.fcn["MSP_SP0_step2"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 30,
	stackTotal: 30};
	 this.metricsArray.fcn["MSP_SP0_step3"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 26,
	stackTotal: 26};
	 this.metricsArray.fcn["MSP_SP0_terminate"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_SP0_ert_rtw/MSP_SP0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sin"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data;}
}
	 CodeMetrics.instance = new CodeMetrics();
