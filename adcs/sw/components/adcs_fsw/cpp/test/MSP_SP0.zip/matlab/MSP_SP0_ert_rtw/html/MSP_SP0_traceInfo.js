function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S2>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:10"] = "MSP_SP0.c:101&MSP_SP0.h:61&MSP_SP0_data.c:28";
	/* <S2>/Discrete
Transfer Fcn1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:47"] = "MSP_SP0.c:86,102,118&MSP_SP0.h:48";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:31:9"] = "MSP_SP0.c:103";
	/* <S2>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:31:59"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:31:59";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:60"] = "MSP_SP0.c:93,116";
	/* <S3>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:32:82"] = "MSP_SP0.c:183";
	/* <S3>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:32:72"] = "MSP_SP0.c:148,163,232,257,282&MSP_SP0.h:47";
	/* <S3>/Gain */
	this.urlHashMap["adcs_sim_main:42:117:66:32:70"] = "MSP_SP0.c:214,233,239,258,264,283";
	/* <S3>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:32:71"] = "MSP_SP0.c:184";
	/* <S3>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:32:29"] = "MSP_SP0.c:161,171";
	/* <S3>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:32:51"] = "MSP_SP0.c:164,173";
	/* <S3>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:32:57"] = "MSP_SP0.c:72,156,185,197,202,215,240,265&MSP_SP0.h:50,53,54";
	/* <S3>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:32:58"] = "MSP_SP0.c:159,194";
	/* <S3>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:32:62"] = "MSP_SP0.c:58,153,186,206,211,216,241,266&MSP_SP0.h:49,51,52";
	/* <S3>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:32:30"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:32:30";
	/* <S3>/Sum1 */
	this.urlHashMap["adcs_sim_main:42:117:66:32:69"] = "MSP_SP0.c:234,259,284";
	/* <S3>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:32:65"] = "MSP_SP0.c:205,217,242,267";
	/* <S3>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:32:67"] = "MSP_SP0.c:196,218,243,268";
	/* <S3>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:32:27"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:32:27";
	/* <S3>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:32:28"] = "MSP_SP0.c:162&MSP_SP0.h:62&MSP_SP0_data.c:29";
	/* <S3>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:32:52"] = "MSP_SP0.c:176&MSP_SP0.h:63&MSP_SP0_data.c:30";
	/* <S3>/zeros */
	this.urlHashMap["adcs_sim_main:42:117:66:32:66"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:32:66";
	/* <S3>/zeros  */
	this.urlHashMap["adcs_sim_main:42:117:66:32:68"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:32:68";
	/* <S4>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:24"] = "MSP_SP0.c:327,338";
	/* <S4>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:48"] = "MSP_SP0.c:329,342";
	/* <S4>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:55"] = "MSP_SP0.c:109&MSP_SP0.h:46";
	/* <S4>/Rate Transition6 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:56"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:56";
	/* <S4>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:21"] = "MSP_SP0.c:322,330";
	/* <S4>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:19:22"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:22";
	/* <S4>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:19:23"] = "MSP_SP0.c:328&MSP_SP0.h:64&MSP_SP0_data.c:31";
	/* <S4>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:19:49"] = "MSP_SP0.c:341&MSP_SP0.h:65&MSP_SP0_data.c:32";
	/* <S5>/Constant */
	this.urlHashMap["adcs_sim_main:42:117:66:19:93"] = "MSP_SP0.c:306";
	/* <S5>/Math
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:96"] = "MSP_SP0.c:307";
	/* <S5>/Math
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:97"] = "MSP_SP0.c:308";
	/* <S5>/Saturation */
	this.urlHashMap["adcs_sim_main:42:117:66:19:98"] = "MSP_SP0.c:309";
	/* <S5>/Sqrt */
	this.urlHashMap["adcs_sim_main:42:117:66:19:94"] = "MSP_SP0.c:305,323";
	/* <S5>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:90"] = "MSP_SP0.c:310";
	/* <S5>/Trigonometric
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:88"] = "MSP_SP0.c:299";
	/* <S5>/Trigonometric
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:89"] = "MSP_SP0.c:302";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_SP0"};
	this.sidHashMap["MSP_SP0"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:117:66"};
	this.sidHashMap["adcs_sim_main:42:117:66"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:117:66:32"};
	this.sidHashMap["adcs_sim_main:42:117:66:32"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S1>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:33"] = {rtwname: "<S1>/mag1_body_T"};
	this.rtwnameHashMap["<S1>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:37"] = {rtwname: "<S1>/mag2_body_T"};
	this.rtwnameHashMap["<S1>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:34"] = {rtwname: "<S1>/omega_radps_gyro"};
	this.rtwnameHashMap["<S1>/sun_vec_body_angles"] = {sid: "adcs_sim_main:42:117:66:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:4"] = {rtwname: "<S1>/sun_vec_body_angles"};
	this.rtwnameHashMap["<S1>/gyro_processing_lib"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S1>/gyro_processing_lib"};
	this.rtwnameHashMap["<S1>/magnetometer_processing_lib"] = {sid: "adcs_sim_main:42:117:66:32"};
	this.sidHashMap["adcs_sim_main:42:117:66:32"] = {rtwname: "<S1>/magnetometer_processing_lib"};
	this.rtwnameHashMap["<S1>/sunsensor_processing_lib"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S1>/sunsensor_processing_lib"};
	this.rtwnameHashMap["<S1>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:35"] = {rtwname: "<S1>/mag_body_processed_T"};
	this.rtwnameHashMap["<S1>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:36"] = {rtwname: "<S1>/omega_radps_processed"};
	this.rtwnameHashMap["<S1>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:20"] = {rtwname: "<S1>/sun_vec_body"};
	this.rtwnameHashMap["<S2>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:31:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:5"] = {rtwname: "<S2>/omega_radps_gyro"};
	this.rtwnameHashMap["<S2>/Constant1"] = {sid: "adcs_sim_main:42:117:66:31:10"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:10"] = {rtwname: "<S2>/Constant1"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:117:66:31:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:78"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn1"] = {sid: "adcs_sim_main:42:117:66:31:47"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:47"] = {rtwname: "<S2>/Discrete Transfer Fcn1"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:117:66:31:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:80"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:117:66:31:9"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:9"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:31:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:59"] = {rtwname: "<S2>/Rate Transition"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:31:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:60"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:31:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:6"] = {rtwname: "<S2>/omega_radps_processed"};
	this.rtwnameHashMap["<S3>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:32:26"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:26"] = {rtwname: "<S3>/mag1_body_T"};
	this.rtwnameHashMap["<S3>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:32:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:61"] = {rtwname: "<S3>/mag2_body_T"};
	this.rtwnameHashMap["<S3>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:32:82"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:82"] = {rtwname: "<S3>/Data Type Conversion"};
	this.rtwnameHashMap["<S3>/Demux1"] = {sid: "adcs_sim_main:42:117:66:32:63"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:63"] = {rtwname: "<S3>/Demux1"};
	this.rtwnameHashMap["<S3>/Demux2"] = {sid: "adcs_sim_main:42:117:66:32:64"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:64"] = {rtwname: "<S3>/Demux2"};
	this.rtwnameHashMap["<S3>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:32:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:72"] = {rtwname: "<S3>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S3>/Gain"] = {sid: "adcs_sim_main:42:117:66:32:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:70"] = {rtwname: "<S3>/Gain"};
	this.rtwnameHashMap["<S3>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:32:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:71"] = {rtwname: "<S3>/Logical Operator"};
	this.rtwnameHashMap["<S3>/Mux"] = {sid: "adcs_sim_main:42:117:66:32:81"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:81"] = {rtwname: "<S3>/Mux"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "adcs_sim_main:42:117:66:32:29"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:29"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Product1"] = {sid: "adcs_sim_main:42:117:66:32:51"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:51"] = {rtwname: "<S3>/Product1"};
	this.rtwnameHashMap["<S3>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:32:57"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:57"] = {rtwname: "<S3>/Rate Transition"};
	this.rtwnameHashMap["<S3>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:32:58"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:58"] = {rtwname: "<S3>/Rate Transition1"};
	this.rtwnameHashMap["<S3>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:32:62"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:62"] = {rtwname: "<S3>/Rate Transition2"};
	this.rtwnameHashMap["<S3>/Sum"] = {sid: "adcs_sim_main:42:117:66:32:30"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:30"] = {rtwname: "<S3>/Sum"};
	this.rtwnameHashMap["<S3>/Sum1"] = {sid: "adcs_sim_main:42:117:66:32:69"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:69"] = {rtwname: "<S3>/Sum1"};
	this.rtwnameHashMap["<S3>/Switch"] = {sid: "adcs_sim_main:42:117:66:32:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:65"] = {rtwname: "<S3>/Switch"};
	this.rtwnameHashMap["<S3>/Switch1"] = {sid: "adcs_sim_main:42:117:66:32:67"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:67"] = {rtwname: "<S3>/Switch1"};
	this.rtwnameHashMap["<S3>/bias"] = {sid: "adcs_sim_main:42:117:66:32:27"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:27"] = {rtwname: "<S3>/bias"};
	this.rtwnameHashMap["<S3>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:32:28"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:28"] = {rtwname: "<S3>/process_matrix"};
	this.rtwnameHashMap["<S3>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:32:52"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:52"] = {rtwname: "<S3>/sensor2body"};
	this.rtwnameHashMap["<S3>/zeros"] = {sid: "adcs_sim_main:42:117:66:32:66"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:66"] = {rtwname: "<S3>/zeros"};
	this.rtwnameHashMap["<S3>/zeros "] = {sid: "adcs_sim_main:42:117:66:32:68"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:68"] = {rtwname: "<S3>/zeros "};
	this.rtwnameHashMap["<S3>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:32:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:32:31"] = {rtwname: "<S3>/mag_body_processed_T"};
	this.rtwnameHashMap["<S4>/sunsensor_angles"] = {sid: "adcs_sim_main:42:117:66:19:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:19"] = {rtwname: "<S4>/sunsensor_angles"};
	this.rtwnameHashMap["<S4>/Demux"] = {sid: "adcs_sim_main:42:117:66:19:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:40"] = {rtwname: "<S4>/Demux"};
	this.rtwnameHashMap["<S4>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:41"] = {rtwname: "<S4>/Mux"};
	this.rtwnameHashMap["<S4>/Product"] = {sid: "adcs_sim_main:42:117:66:19:24"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:24"] = {rtwname: "<S4>/Product"};
	this.rtwnameHashMap["<S4>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:48"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:48"] = {rtwname: "<S4>/Product1"};
	this.rtwnameHashMap["<S4>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:19:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:55"] = {rtwname: "<S4>/Rate Transition1"};
	this.rtwnameHashMap["<S4>/Rate Transition6"] = {sid: "adcs_sim_main:42:117:66:19:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:56"] = {rtwname: "<S4>/Rate Transition6"};
	this.rtwnameHashMap["<S4>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:21"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:21"] = {rtwname: "<S4>/Sum"};
	this.rtwnameHashMap["<S4>/angles_to_vec"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S4>/angles_to_vec"};
	this.rtwnameHashMap["<S4>/bias"] = {sid: "adcs_sim_main:42:117:66:19:22"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:22"] = {rtwname: "<S4>/bias"};
	this.rtwnameHashMap["<S4>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:19:23"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:23"] = {rtwname: "<S4>/process_matrix"};
	this.rtwnameHashMap["<S4>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:19:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:49"] = {rtwname: "<S4>/sensor2body"};
	this.rtwnameHashMap["<S4>/sunsensor_body_processed"] = {sid: "adcs_sim_main:42:117:66:19:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:20"] = {rtwname: "<S4>/sunsensor_body_processed"};
	this.rtwnameHashMap["<S5>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:84"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:84"] = {rtwname: "<S5>/alpha"};
	this.rtwnameHashMap["<S5>/beta"] = {sid: "adcs_sim_main:42:117:66:19:86"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:86"] = {rtwname: "<S5>/beta"};
	this.rtwnameHashMap["<S5>/Constant"] = {sid: "adcs_sim_main:42:117:66:19:93"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:93"] = {rtwname: "<S5>/Constant"};
	this.rtwnameHashMap["<S5>/Math Function"] = {sid: "adcs_sim_main:42:117:66:19:96"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:96"] = {rtwname: "<S5>/Math Function"};
	this.rtwnameHashMap["<S5>/Math Function1"] = {sid: "adcs_sim_main:42:117:66:19:97"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:97"] = {rtwname: "<S5>/Math Function1"};
	this.rtwnameHashMap["<S5>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:95"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:95"] = {rtwname: "<S5>/Mux"};
	this.rtwnameHashMap["<S5>/Saturation"] = {sid: "adcs_sim_main:42:117:66:19:98"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:98"] = {rtwname: "<S5>/Saturation"};
	this.rtwnameHashMap["<S5>/Sqrt"] = {sid: "adcs_sim_main:42:117:66:19:94"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:94"] = {rtwname: "<S5>/Sqrt"};
	this.rtwnameHashMap["<S5>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:90"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:90"] = {rtwname: "<S5>/Sum"};
	this.rtwnameHashMap["<S5>/Trigonometric Function"] = {sid: "adcs_sim_main:42:117:66:19:88"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:88"] = {rtwname: "<S5>/Trigonometric Function"};
	this.rtwnameHashMap["<S5>/Trigonometric Function1"] = {sid: "adcs_sim_main:42:117:66:19:89"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:89"] = {rtwname: "<S5>/Trigonometric Function1"};
	this.rtwnameHashMap["<S5>/sunsensor_unit_body"] = {sid: "adcs_sim_main:42:117:66:19:85"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:85"] = {rtwname: "<S5>/sunsensor_unit_body"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
