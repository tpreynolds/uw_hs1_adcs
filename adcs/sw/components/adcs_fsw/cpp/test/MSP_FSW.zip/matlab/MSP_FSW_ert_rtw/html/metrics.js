function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 889};
	 this.metricsArray.var["rtInf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 4};
	 this.metricsArray.var["rtM_"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 5};
	 this.metricsArray.var["rtMinusInf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 4};
	 this.metricsArray.var["rtU"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 158};
	 this.metricsArray.var["rtY"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	size: 63};
	 this.metricsArray.fcn["MSP_FSW.c:mrdivide"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 326,
	stackTotal: 326};
	 this.metricsArray.fcn["MSP_FSW.c:myDCM2quat"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["MSP_FSW.c:norm"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["MSP_FSW.c:norm_i"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["MSP_FSW_initialize"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 22};
	 this.metricsArray.fcn["MSP_FSW_step0"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["MSP_FSW_step1"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 3222,
	stackTotal: 3548};
	 this.metricsArray.fcn["MSP_FSW_step2"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 70,
	stackTotal: 70};
	 this.metricsArray.fcn["MSP_FSW_terminate"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["acos"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["cos"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memcpy"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memset"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["pow"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtGetInf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 18,
	stackTotal: 22};
	 this.metricsArray.fcn["rtGetInfF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetMinusInf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 18,
	stackTotal: 22};
	 this.metricsArray.fcn["rtGetMinusInfF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetNaN"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 18,
	stackTotal: 22};
	 this.metricsArray.fcn["rtGetNaNF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtIsInf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsInfF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaN"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaNF"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_InitInfAndNaN"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 0,
	stackTotal: 22};
	 this.metricsArray.fcn["rt_powd_snf"] = {file: "/Users/Taylor/uw_hs1_adcs/adcs/sw/components/adcs_sim/matlab/MSP_FSW_ert_rtw/MSP_FSW.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["sin"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data;}
}
	 CodeMetrics.instance = new CodeMetrics();
