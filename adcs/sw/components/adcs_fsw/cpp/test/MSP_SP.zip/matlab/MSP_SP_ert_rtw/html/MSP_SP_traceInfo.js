function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S2>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:10"] = "MSP_SP.c:128&MSP_SP.h:57&MSP_SP_data.c:28";
	/* <S2>/Discrete
Transfer Fcn1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:47"] = "MSP_SP.c:113,129,145&MSP_SP.h:50";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:31:9"] = "MSP_SP.c:130";
	/* <S2>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:31:59"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:31:59";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:60"] = "MSP_SP.c:120,143";
	/* <S3>/1 */
	this.urlHashMap["adcs_sim_main:42:117:66:51"] = "MSP_SP.c:214";
	/* <S3>/2 */
	this.urlHashMap["adcs_sim_main:42:117:66:52"] = "MSP_SP.c:215";
	/* <S3>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:53"] = "MSP_SP.c:206";
	/* <S3>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:56"] = "MSP_SP.c:173,186,239,260,281&MSP_SP.h:49";
	/* <S3>/Divide */
	this.urlHashMap["adcs_sim_main:42:117:66:57"] = "MSP_SP.c:240,261,282";
	/* <S3>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:58"] = "MSP_SP.c:178";
	/* <S3>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:60"] = "MSP_SP.c:184,194";
	/* <S3>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:61"] = "MSP_SP.c:187,196";
	/* <S3>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:62"] = "MSP_SP.c:83,90,97,104&MSP_SP.h:47";
	/* <S3>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:63"] = "MSP_SP.c:182,211";
	/* <S3>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:64"] = "MSP_SP.c:77,111&MSP_SP.h:46";
	/* <S3>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:65"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:65";
	/* <S3>/Sum1 */
	this.urlHashMap["adcs_sim_main:42:117:66:66"] = "MSP_SP.c:241,262,283";
	/* <S3>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:67"] = "MSP_SP.c:232,253,274";
	/* <S3>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:68"] = "MSP_SP.c:225,246,267";
	/* <S3>/Switch2 */
	this.urlHashMap["adcs_sim_main:42:117:66:69"] = "MSP_SP.c:213,223";
	/* <S3>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:70"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:70";
	/* <S3>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:71"] = "MSP_SP.c:185&MSP_SP.h:58&MSP_SP_data.c:29";
	/* <S3>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:72"] = "MSP_SP.c:199&MSP_SP.h:59&MSP_SP_data.c:30";
	/* <S3>/zeros */
	this.urlHashMap["adcs_sim_main:42:117:66:73"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:73";
	/* <S3>/zeros  */
	this.urlHashMap["adcs_sim_main:42:117:66:74"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:74";
	/* <S4>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:81"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:81";
	/* <S4>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:82"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:82";
	/* <S4>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:83"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:83";
	/* <S4>/Rate Transition3 */
	this.urlHashMap["adcs_sim_main:42:117:66:84"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:84";
	/* <S4>/Rate Transition4 */
	this.urlHashMap["adcs_sim_main:42:117:66:85"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:85";
	/* <S4>/Rate Transition5 */
	this.urlHashMap["adcs_sim_main:42:117:66:86"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:86";
	/* <S5>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:117"] = "MSP_SP.c:364";
	/* <S5>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:116"] = "MSP_SP.c:365";
	/* <S5>/MATLAB Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115"] = "MSP_SP.c:367";
	/* <S5>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:24"] = "MSP_SP.c:342,353";
	/* <S5>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:48"] = "MSP_SP.c:344,357";
	/* <S5>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:55"] = "MSP_SP.c:136&MSP_SP.h:48";
	/* <S5>/Rate Transition6 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:56"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:56";
	/* <S5>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:21"] = "MSP_SP.c:337,345";
	/* <S5>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:19:22"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:22";
	/* <S5>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:19:23"] = "MSP_SP.c:343&MSP_SP.h:60&MSP_SP_data.c:31";
	/* <S5>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:19:49"] = "MSP_SP.c:356&MSP_SP.h:61&MSP_SP_data.c:32";
	/* <S6>:1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115:1"] = "MSP_SP.c:325";
	/* <S6>:1:4 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115:1:4"] = "MSP_SP.c:326";
	/* <S7>/Abs */
	this.urlHashMap["adcs_sim_main:42:117:66:19:101"] = "MSP_SP.c:312";
	/* <S7>/Abs1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:102"] = "MSP_SP.c:315";
	/* <S7>/Constant */
	this.urlHashMap["adcs_sim_main:42:117:66:19:93"] = "MSP_SP.c:319";
	/* <S7>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:112"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:112";
	/* <S7>/Constant2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:103"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:103";
	/* <S7>/Constant3 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:104"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:104";
	/* <S7>/Constant4 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:105"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:105";
	/* <S7>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:118"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:118";
	/* <S7>/Data Type Conversion1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:119"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:119";
	/* <S7>/Data Type Conversion2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:120"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:120";
	/* <S7>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:106"] = "MSP_SP.c:366";
	/* <S7>/Math
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:96"] = "MSP_SP.c:320";
	/* <S7>/Math
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:97"] = "MSP_SP.c:321";
	/* <S7>/Saturation */
	this.urlHashMap["adcs_sim_main:42:117:66:19:98"] = "MSP_SP.c:322";
	/* <S7>/Sqrt */
	this.urlHashMap["adcs_sim_main:42:117:66:19:94"] = "MSP_SP.c:318,338";
	/* <S7>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:90"] = "MSP_SP.c:323";
	/* <S7>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:19:107"] = "MSP_SP.c:368";
	/* <S7>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:108"] = "MSP_SP.c:369";
	/* <S7>/Trigonometric
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:88"] = "MSP_SP.c:303";
	/* <S7>/Trigonometric
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:89"] = "MSP_SP.c:309";
	/* <S7>/deg2rad */
	this.urlHashMap["adcs_sim_main:42:117:66:19:99"] = "MSP_SP.c:300";
	/* <S7>/deg2rad  */
	this.urlHashMap["adcs_sim_main:42:117:66:19:100"] = "MSP_SP.c:306";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_SP"};
	this.sidHashMap["MSP_SP"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:117:66"};
	this.sidHashMap["adcs_sim_main:42:117:66"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:117:66:76"};
	this.sidHashMap["adcs_sim_main:42:117:66:76"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "adcs_sim_main:42:117:66:19:115"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<S1>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:33"] = {rtwname: "<S1>/mag1_body_T"};
	this.rtwnameHashMap["<S1>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:37"] = {rtwname: "<S1>/mag2_body_T"};
	this.rtwnameHashMap["<S1>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:34"] = {rtwname: "<S1>/omega_radps_gyro"};
	this.rtwnameHashMap["<S1>/sun_vec_body_angles"] = {sid: "adcs_sim_main:42:117:66:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:4"] = {rtwname: "<S1>/sun_vec_body_angles"};
	this.rtwnameHashMap["<S1>/gyro_processing_lib"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S1>/gyro_processing_lib"};
	this.rtwnameHashMap["<S1>/magnetometer_processing_lib"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S1>/magnetometer_processing_lib"};
	this.rtwnameHashMap["<S1>/rate_transition"] = {sid: "adcs_sim_main:42:117:66:76"};
	this.sidHashMap["adcs_sim_main:42:117:66:76"] = {rtwname: "<S1>/rate_transition"};
	this.rtwnameHashMap["<S1>/sunsensor_processing_lib"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S1>/sunsensor_processing_lib"};
	this.rtwnameHashMap["<S1>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:35"] = {rtwname: "<S1>/mag_body_processed_T"};
	this.rtwnameHashMap["<S1>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:36"] = {rtwname: "<S1>/omega_radps_processed"};
	this.rtwnameHashMap["<S1>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:20"] = {rtwname: "<S1>/sun_vec_body"};
	this.rtwnameHashMap["<S2>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:31:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:5"] = {rtwname: "<S2>/omega_radps_gyro"};
	this.rtwnameHashMap["<S2>/Constant1"] = {sid: "adcs_sim_main:42:117:66:31:10"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:10"] = {rtwname: "<S2>/Constant1"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:117:66:31:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:78"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn1"] = {sid: "adcs_sim_main:42:117:66:31:47"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:47"] = {rtwname: "<S2>/Discrete Transfer Fcn1"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:117:66:31:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:80"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:117:66:31:9"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:9"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:31:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:59"] = {rtwname: "<S2>/Rate Transition"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:31:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:60"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:31:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:6"] = {rtwname: "<S2>/omega_radps_processed"};
	this.rtwnameHashMap["<S3>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:49"] = {rtwname: "<S3>/mag1_body_T"};
	this.rtwnameHashMap["<S3>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:50"};
	this.sidHashMap["adcs_sim_main:42:117:66:50"] = {rtwname: "<S3>/mag2_body_T"};
	this.rtwnameHashMap["<S3>/1"] = {sid: "adcs_sim_main:42:117:66:51"};
	this.sidHashMap["adcs_sim_main:42:117:66:51"] = {rtwname: "<S3>/1"};
	this.rtwnameHashMap["<S3>/2"] = {sid: "adcs_sim_main:42:117:66:52"};
	this.sidHashMap["adcs_sim_main:42:117:66:52"] = {rtwname: "<S3>/2"};
	this.rtwnameHashMap["<S3>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:53"};
	this.sidHashMap["adcs_sim_main:42:117:66:53"] = {rtwname: "<S3>/Data Type Conversion"};
	this.rtwnameHashMap["<S3>/Demux1"] = {sid: "adcs_sim_main:42:117:66:54"};
	this.sidHashMap["adcs_sim_main:42:117:66:54"] = {rtwname: "<S3>/Demux1"};
	this.rtwnameHashMap["<S3>/Demux2"] = {sid: "adcs_sim_main:42:117:66:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:55"] = {rtwname: "<S3>/Demux2"};
	this.rtwnameHashMap["<S3>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:56"] = {rtwname: "<S3>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S3>/Divide"] = {sid: "adcs_sim_main:42:117:66:57"};
	this.sidHashMap["adcs_sim_main:42:117:66:57"] = {rtwname: "<S3>/Divide"};
	this.rtwnameHashMap["<S3>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:58"};
	this.sidHashMap["adcs_sim_main:42:117:66:58"] = {rtwname: "<S3>/Logical Operator"};
	this.rtwnameHashMap["<S3>/Mux"] = {sid: "adcs_sim_main:42:117:66:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:59"] = {rtwname: "<S3>/Mux"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "adcs_sim_main:42:117:66:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:60"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Product1"] = {sid: "adcs_sim_main:42:117:66:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:61"] = {rtwname: "<S3>/Product1"};
	this.rtwnameHashMap["<S3>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:62"};
	this.sidHashMap["adcs_sim_main:42:117:66:62"] = {rtwname: "<S3>/Rate Transition"};
	this.rtwnameHashMap["<S3>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:63"};
	this.sidHashMap["adcs_sim_main:42:117:66:63"] = {rtwname: "<S3>/Rate Transition1"};
	this.rtwnameHashMap["<S3>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:64"};
	this.sidHashMap["adcs_sim_main:42:117:66:64"] = {rtwname: "<S3>/Rate Transition2"};
	this.rtwnameHashMap["<S3>/Sum"] = {sid: "adcs_sim_main:42:117:66:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:65"] = {rtwname: "<S3>/Sum"};
	this.rtwnameHashMap["<S3>/Sum1"] = {sid: "adcs_sim_main:42:117:66:66"};
	this.sidHashMap["adcs_sim_main:42:117:66:66"] = {rtwname: "<S3>/Sum1"};
	this.rtwnameHashMap["<S3>/Switch"] = {sid: "adcs_sim_main:42:117:66:67"};
	this.sidHashMap["adcs_sim_main:42:117:66:67"] = {rtwname: "<S3>/Switch"};
	this.rtwnameHashMap["<S3>/Switch1"] = {sid: "adcs_sim_main:42:117:66:68"};
	this.sidHashMap["adcs_sim_main:42:117:66:68"] = {rtwname: "<S3>/Switch1"};
	this.rtwnameHashMap["<S3>/Switch2"] = {sid: "adcs_sim_main:42:117:66:69"};
	this.sidHashMap["adcs_sim_main:42:117:66:69"] = {rtwname: "<S3>/Switch2"};
	this.rtwnameHashMap["<S3>/bias"] = {sid: "adcs_sim_main:42:117:66:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:70"] = {rtwname: "<S3>/bias"};
	this.rtwnameHashMap["<S3>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:71"] = {rtwname: "<S3>/process_matrix"};
	this.rtwnameHashMap["<S3>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:72"] = {rtwname: "<S3>/sensor2body"};
	this.rtwnameHashMap["<S3>/zeros"] = {sid: "adcs_sim_main:42:117:66:73"};
	this.sidHashMap["adcs_sim_main:42:117:66:73"] = {rtwname: "<S3>/zeros"};
	this.rtwnameHashMap["<S3>/zeros "] = {sid: "adcs_sim_main:42:117:66:74"};
	this.sidHashMap["adcs_sim_main:42:117:66:74"] = {rtwname: "<S3>/zeros "};
	this.rtwnameHashMap["<S3>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:75"};
	this.sidHashMap["adcs_sim_main:42:117:66:75"] = {rtwname: "<S3>/mag_body_processed_T"};
	this.rtwnameHashMap["<S4>/mag_body_T"] = {sid: "adcs_sim_main:42:117:66:77"};
	this.sidHashMap["adcs_sim_main:42:117:66:77"] = {rtwname: "<S4>/mag_body_T"};
	this.rtwnameHashMap["<S4>/omega_radps"] = {sid: "adcs_sim_main:42:117:66:79"};
	this.sidHashMap["adcs_sim_main:42:117:66:79"] = {rtwname: "<S4>/omega_radps"};
	this.rtwnameHashMap["<S4>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:80"] = {rtwname: "<S4>/sun_vec_body"};
	this.rtwnameHashMap["<S4>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:81"};
	this.sidHashMap["adcs_sim_main:42:117:66:81"] = {rtwname: "<S4>/Rate Transition"};
	this.rtwnameHashMap["<S4>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:82"};
	this.sidHashMap["adcs_sim_main:42:117:66:82"] = {rtwname: "<S4>/Rate Transition1"};
	this.rtwnameHashMap["<S4>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:83"] = {rtwname: "<S4>/Rate Transition2"};
	this.rtwnameHashMap["<S4>/Rate Transition3"] = {sid: "adcs_sim_main:42:117:66:84"};
	this.sidHashMap["adcs_sim_main:42:117:66:84"] = {rtwname: "<S4>/Rate Transition3"};
	this.rtwnameHashMap["<S4>/Rate Transition4"] = {sid: "adcs_sim_main:42:117:66:85"};
	this.sidHashMap["adcs_sim_main:42:117:66:85"] = {rtwname: "<S4>/Rate Transition4"};
	this.rtwnameHashMap["<S4>/Rate Transition5"] = {sid: "adcs_sim_main:42:117:66:86"};
	this.sidHashMap["adcs_sim_main:42:117:66:86"] = {rtwname: "<S4>/Rate Transition5"};
	this.rtwnameHashMap["<S4>/mag_body_T_processed"] = {sid: "adcs_sim_main:42:117:66:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:78"] = {rtwname: "<S4>/mag_body_T_processed"};
	this.rtwnameHashMap["<S4>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:87"};
	this.sidHashMap["adcs_sim_main:42:117:66:87"] = {rtwname: "<S4>/omega_radps_processed"};
	this.rtwnameHashMap["<S4>/sun_vec_body_processed"] = {sid: "adcs_sim_main:42:117:66:88"};
	this.sidHashMap["adcs_sim_main:42:117:66:88"] = {rtwname: "<S4>/sun_vec_body_processed"};
	this.rtwnameHashMap["<S5>/sunsensor_angles"] = {sid: "adcs_sim_main:42:117:66:19:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:19"] = {rtwname: "<S5>/sunsensor_angles"};
	this.rtwnameHashMap["<S5>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:117"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:117"] = {rtwname: "<S5>/Data Type Conversion"};
	this.rtwnameHashMap["<S5>/Demux"] = {sid: "adcs_sim_main:42:117:66:19:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:40"] = {rtwname: "<S5>/Demux"};
	this.rtwnameHashMap["<S5>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:116"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:116"] = {rtwname: "<S5>/Logical Operator"};
	this.rtwnameHashMap["<S5>/MATLAB Function"] = {sid: "adcs_sim_main:42:117:66:19:115"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115"] = {rtwname: "<S5>/MATLAB Function"};
	this.rtwnameHashMap["<S5>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:41"] = {rtwname: "<S5>/Mux"};
	this.rtwnameHashMap["<S5>/Product"] = {sid: "adcs_sim_main:42:117:66:19:24"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:24"] = {rtwname: "<S5>/Product"};
	this.rtwnameHashMap["<S5>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:48"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:48"] = {rtwname: "<S5>/Product1"};
	this.rtwnameHashMap["<S5>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:19:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:55"] = {rtwname: "<S5>/Rate Transition1"};
	this.rtwnameHashMap["<S5>/Rate Transition6"] = {sid: "adcs_sim_main:42:117:66:19:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:56"] = {rtwname: "<S5>/Rate Transition6"};
	this.rtwnameHashMap["<S5>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:21"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:21"] = {rtwname: "<S5>/Sum"};
	this.rtwnameHashMap["<S5>/angles_to_vec"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S5>/angles_to_vec"};
	this.rtwnameHashMap["<S5>/bias"] = {sid: "adcs_sim_main:42:117:66:19:22"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:22"] = {rtwname: "<S5>/bias"};
	this.rtwnameHashMap["<S5>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:19:23"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:23"] = {rtwname: "<S5>/process_matrix"};
	this.rtwnameHashMap["<S5>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:19:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:49"] = {rtwname: "<S5>/sensor2body"};
	this.rtwnameHashMap["<S5>/sunsensor_body_processed"] = {sid: "adcs_sim_main:42:117:66:19:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:20"] = {rtwname: "<S5>/sunsensor_body_processed"};
	this.rtwnameHashMap["<S6>:1"] = {sid: "adcs_sim_main:42:117:66:19:115:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115:1"] = {rtwname: "<S6>:1"};
	this.rtwnameHashMap["<S6>:1:4"] = {sid: "adcs_sim_main:42:117:66:19:115:1:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115:1:4"] = {rtwname: "<S6>:1:4"};
	this.rtwnameHashMap["<S7>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:84"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:84"] = {rtwname: "<S7>/alpha"};
	this.rtwnameHashMap["<S7>/beta"] = {sid: "adcs_sim_main:42:117:66:19:86"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:86"] = {rtwname: "<S7>/beta"};
	this.rtwnameHashMap["<S7>/Abs"] = {sid: "adcs_sim_main:42:117:66:19:101"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:101"] = {rtwname: "<S7>/Abs"};
	this.rtwnameHashMap["<S7>/Abs1"] = {sid: "adcs_sim_main:42:117:66:19:102"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:102"] = {rtwname: "<S7>/Abs1"};
	this.rtwnameHashMap["<S7>/Constant"] = {sid: "adcs_sim_main:42:117:66:19:93"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:93"] = {rtwname: "<S7>/Constant"};
	this.rtwnameHashMap["<S7>/Constant1"] = {sid: "adcs_sim_main:42:117:66:19:112"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:112"] = {rtwname: "<S7>/Constant1"};
	this.rtwnameHashMap["<S7>/Constant2"] = {sid: "adcs_sim_main:42:117:66:19:103"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:103"] = {rtwname: "<S7>/Constant2"};
	this.rtwnameHashMap["<S7>/Constant3"] = {sid: "adcs_sim_main:42:117:66:19:104"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:104"] = {rtwname: "<S7>/Constant3"};
	this.rtwnameHashMap["<S7>/Constant4"] = {sid: "adcs_sim_main:42:117:66:19:105"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:105"] = {rtwname: "<S7>/Constant4"};
	this.rtwnameHashMap["<S7>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:118"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:118"] = {rtwname: "<S7>/Data Type Conversion"};
	this.rtwnameHashMap["<S7>/Data Type Conversion1"] = {sid: "adcs_sim_main:42:117:66:19:119"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:119"] = {rtwname: "<S7>/Data Type Conversion1"};
	this.rtwnameHashMap["<S7>/Data Type Conversion2"] = {sid: "adcs_sim_main:42:117:66:19:120"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:120"] = {rtwname: "<S7>/Data Type Conversion2"};
	this.rtwnameHashMap["<S7>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:106"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:106"] = {rtwname: "<S7>/Logical Operator"};
	this.rtwnameHashMap["<S7>/Math Function"] = {sid: "adcs_sim_main:42:117:66:19:96"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:96"] = {rtwname: "<S7>/Math Function"};
	this.rtwnameHashMap["<S7>/Math Function1"] = {sid: "adcs_sim_main:42:117:66:19:97"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:97"] = {rtwname: "<S7>/Math Function1"};
	this.rtwnameHashMap["<S7>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:95"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:95"] = {rtwname: "<S7>/Mux"};
	this.rtwnameHashMap["<S7>/Saturation"] = {sid: "adcs_sim_main:42:117:66:19:98"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:98"] = {rtwname: "<S7>/Saturation"};
	this.rtwnameHashMap["<S7>/Sqrt"] = {sid: "adcs_sim_main:42:117:66:19:94"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:94"] = {rtwname: "<S7>/Sqrt"};
	this.rtwnameHashMap["<S7>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:90"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:90"] = {rtwname: "<S7>/Sum"};
	this.rtwnameHashMap["<S7>/Switch"] = {sid: "adcs_sim_main:42:117:66:19:107"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:107"] = {rtwname: "<S7>/Switch"};
	this.rtwnameHashMap["<S7>/Switch1"] = {sid: "adcs_sim_main:42:117:66:19:108"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:108"] = {rtwname: "<S7>/Switch1"};
	this.rtwnameHashMap["<S7>/Trigonometric Function"] = {sid: "adcs_sim_main:42:117:66:19:88"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:88"] = {rtwname: "<S7>/Trigonometric Function"};
	this.rtwnameHashMap["<S7>/Trigonometric Function1"] = {sid: "adcs_sim_main:42:117:66:19:89"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:89"] = {rtwname: "<S7>/Trigonometric Function1"};
	this.rtwnameHashMap["<S7>/deg2rad"] = {sid: "adcs_sim_main:42:117:66:19:99"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:99"] = {rtwname: "<S7>/deg2rad"};
	this.rtwnameHashMap["<S7>/deg2rad "] = {sid: "adcs_sim_main:42:117:66:19:100"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:100"] = {rtwname: "<S7>/deg2rad "};
	this.rtwnameHashMap["<S7>/sunsensor_unit_body"] = {sid: "adcs_sim_main:42:117:66:19:85"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:85"] = {rtwname: "<S7>/sunsensor_unit_body"};
	this.rtwnameHashMap["<S7>/sunsensor_angles_in_range"] = {sid: "adcs_sim_main:42:117:66:19:109"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:109"] = {rtwname: "<S7>/sunsensor_angles_in_range"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
