function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	size: 68};
	 this.metricsArray.var["rtM_"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	size: 5};
	 this.metricsArray.var["rtU"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	size: 60};
	 this.metricsArray.var["rtY"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	size: 48};
	 this.metricsArray.fcn["MSP_SP_initialize"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MSP_SP_step0"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 14,
	stackTotal: 14};
	 this.metricsArray.fcn["MSP_SP_step1"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 26,
	stackTotal: 26};
	 this.metricsArray.fcn["MSP_SP_step2"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 34,
	stackTotal: 38};
	 this.metricsArray.fcn["MSP_SP_terminate"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ceil"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_roundf_snf"] = {file: "/Users/taylorreynolds/uw_hs1_adcs/uw_hs1_adcs/adcs/sw/components/adcs_fsw/cpp/test/MSP_SP_ert_rtw/MSP_SP.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["sin"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data;}
}
	 CodeMetrics.instance = new CodeMetrics();
