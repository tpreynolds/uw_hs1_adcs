function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S2>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:10"] = "MSP_SP.c:128&MSP_SP.h:57&MSP_SP_data.c:28";
	/* <S2>/Discrete
Transfer Fcn1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:47"] = "MSP_SP.c:113,129,145&MSP_SP.h:50";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:31:9"] = "MSP_SP.c:130";
	/* <S2>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:31:59"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:31:59";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:60"] = "MSP_SP.c:120,143";
	/* <S3>/1 */
	this.urlHashMap["adcs_sim_main:42:117:66:51"] = "MSP_SP.c:211";
	/* <S3>/2 */
	this.urlHashMap["adcs_sim_main:42:117:66:52"] = "MSP_SP.c:212";
	/* <S3>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:53"] = "MSP_SP.c:201";
	/* <S3>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:56"] = "MSP_SP.c:172,181,237,258,279&MSP_SP.h:49";
	/* <S3>/Divide */
	this.urlHashMap["adcs_sim_main:42:117:66:57"] = "MSP_SP.c:238,259,280";
	/* <S3>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:58"] = "MSP_SP.c:202";
	/* <S3>/Logical
Operator1 */
	this.urlHashMap["adcs_sim_main:42:117:66:89"] = "MSP_SP.c:213";
	/* <S3>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:60"] = "MSP_SP.c:179,189";
	/* <S3>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:61"] = "MSP_SP.c:182,191";
	/* <S3>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:62"] = "MSP_SP.c:83,90,97,104&MSP_SP.h:47";
	/* <S3>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:63"] = "MSP_SP.c:177,208";
	/* <S3>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:64"] = "MSP_SP.c:77,111&MSP_SP.h:46";
	/* <S3>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:65"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:65";
	/* <S3>/Sum1 */
	this.urlHashMap["adcs_sim_main:42:117:66:66"] = "MSP_SP.c:239,260,281";
	/* <S3>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:67"] = "MSP_SP.c:230,251,272";
	/* <S3>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:68"] = "MSP_SP.c:223,244,265";
	/* <S3>/Switch2 */
	this.urlHashMap["adcs_sim_main:42:117:66:69"] = "MSP_SP.c:210,221";
	/* <S3>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:70"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:70";
	/* <S3>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:71"] = "MSP_SP.c:180&MSP_SP.h:58&MSP_SP_data.c:29";
	/* <S3>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:72"] = "MSP_SP.c:194&MSP_SP.h:59&MSP_SP_data.c:30";
	/* <S3>/zeros */
	this.urlHashMap["adcs_sim_main:42:117:66:73"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:73";
	/* <S3>/zeros  */
	this.urlHashMap["adcs_sim_main:42:117:66:74"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:74";
	/* <S4>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:117"] = "MSP_SP.c:362";
	/* <S4>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:116"] = "MSP_SP.c:363";
	/* <S4>/MATLAB Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115"] = "MSP_SP.c:365";
	/* <S4>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:24"] = "MSP_SP.c:340,351";
	/* <S4>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:48"] = "MSP_SP.c:342,355";
	/* <S4>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:55"] = "MSP_SP.c:136&MSP_SP.h:48";
	/* <S4>/Rate Transition6 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:56"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:56";
	/* <S4>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:21"] = "MSP_SP.c:335,343";
	/* <S4>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:19:22"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:22";
	/* <S4>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:19:23"] = "MSP_SP.c:341&MSP_SP.h:60&MSP_SP_data.c:31";
	/* <S4>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:19:49"] = "MSP_SP.c:354&MSP_SP.h:61&MSP_SP_data.c:32";
	/* <S5>:1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115:1"] = "MSP_SP.c:323";
	/* <S5>:1:4 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:115:1:4"] = "MSP_SP.c:324";
	/* <S6>/Abs */
	this.urlHashMap["adcs_sim_main:42:117:66:19:101"] = "MSP_SP.c:310";
	/* <S6>/Abs1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:102"] = "MSP_SP.c:313";
	/* <S6>/Constant */
	this.urlHashMap["adcs_sim_main:42:117:66:19:93"] = "MSP_SP.c:317";
	/* <S6>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:112"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:112";
	/* <S6>/Constant2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:103"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:103";
	/* <S6>/Constant3 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:104"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:104";
	/* <S6>/Constant4 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:105"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:105";
	/* <S6>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:118"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:118";
	/* <S6>/Data Type Conversion1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:119"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:119";
	/* <S6>/Data Type Conversion2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:120"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:120";
	/* <S6>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:106"] = "MSP_SP.c:364";
	/* <S6>/Math
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:96"] = "MSP_SP.c:318";
	/* <S6>/Math
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:97"] = "MSP_SP.c:319";
	/* <S6>/Saturation */
	this.urlHashMap["adcs_sim_main:42:117:66:19:98"] = "MSP_SP.c:320";
	/* <S6>/Sqrt */
	this.urlHashMap["adcs_sim_main:42:117:66:19:94"] = "MSP_SP.c:316,336";
	/* <S6>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:90"] = "MSP_SP.c:321";
	/* <S6>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:19:107"] = "MSP_SP.c:366";
	/* <S6>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:108"] = "MSP_SP.c:367";
	/* <S6>/Trigonometric
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:88"] = "MSP_SP.c:301";
	/* <S6>/Trigonometric
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:89"] = "MSP_SP.c:307";
	/* <S6>/deg2rad */
	this.urlHashMap["adcs_sim_main:42:117:66:19:99"] = "MSP_SP.c:298";
	/* <S6>/deg2rad  */
	this.urlHashMap["adcs_sim_main:42:117:66:19:100"] = "MSP_SP.c:304";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_SP"};
	this.sidHashMap["MSP_SP"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:117:66"};
	this.sidHashMap["adcs_sim_main:42:117:66"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "adcs_sim_main:42:117:66:19:115"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S1>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:33"] = {rtwname: "<S1>/mag1_body_T"};
	this.rtwnameHashMap["<S1>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:37"] = {rtwname: "<S1>/mag2_body_T"};
	this.rtwnameHashMap["<S1>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:34"] = {rtwname: "<S1>/omega_radps_gyro"};
	this.rtwnameHashMap["<S1>/sun_vec_body_angles"] = {sid: "adcs_sim_main:42:117:66:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:4"] = {rtwname: "<S1>/sun_vec_body_angles"};
	this.rtwnameHashMap["<S1>/gyro_processing_lib"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S1>/gyro_processing_lib"};
	this.rtwnameHashMap["<S1>/magnetometer_processing_lib"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S1>/magnetometer_processing_lib"};
	this.rtwnameHashMap["<S1>/sunsensor_processing_lib"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S1>/sunsensor_processing_lib"};
	this.rtwnameHashMap["<S1>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:35"] = {rtwname: "<S1>/mag_body_processed_T"};
	this.rtwnameHashMap["<S1>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:36"] = {rtwname: "<S1>/omega_radps_processed"};
	this.rtwnameHashMap["<S1>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:20"] = {rtwname: "<S1>/sun_vec_body"};
	this.rtwnameHashMap["<S2>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:31:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:5"] = {rtwname: "<S2>/omega_radps_gyro"};
	this.rtwnameHashMap["<S2>/Constant1"] = {sid: "adcs_sim_main:42:117:66:31:10"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:10"] = {rtwname: "<S2>/Constant1"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:117:66:31:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:78"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn1"] = {sid: "adcs_sim_main:42:117:66:31:47"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:47"] = {rtwname: "<S2>/Discrete Transfer Fcn1"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:117:66:31:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:80"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:117:66:31:9"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:9"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:31:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:59"] = {rtwname: "<S2>/Rate Transition"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:31:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:60"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:31:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:6"] = {rtwname: "<S2>/omega_radps_processed"};
	this.rtwnameHashMap["<S3>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:49"] = {rtwname: "<S3>/mag1_body_T"};
	this.rtwnameHashMap["<S3>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:50"};
	this.sidHashMap["adcs_sim_main:42:117:66:50"] = {rtwname: "<S3>/mag2_body_T"};
	this.rtwnameHashMap["<S3>/1"] = {sid: "adcs_sim_main:42:117:66:51"};
	this.sidHashMap["adcs_sim_main:42:117:66:51"] = {rtwname: "<S3>/1"};
	this.rtwnameHashMap["<S3>/2"] = {sid: "adcs_sim_main:42:117:66:52"};
	this.sidHashMap["adcs_sim_main:42:117:66:52"] = {rtwname: "<S3>/2"};
	this.rtwnameHashMap["<S3>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:53"};
	this.sidHashMap["adcs_sim_main:42:117:66:53"] = {rtwname: "<S3>/Data Type Conversion"};
	this.rtwnameHashMap["<S3>/Demux1"] = {sid: "adcs_sim_main:42:117:66:54"};
	this.sidHashMap["adcs_sim_main:42:117:66:54"] = {rtwname: "<S3>/Demux1"};
	this.rtwnameHashMap["<S3>/Demux2"] = {sid: "adcs_sim_main:42:117:66:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:55"] = {rtwname: "<S3>/Demux2"};
	this.rtwnameHashMap["<S3>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:56"] = {rtwname: "<S3>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S3>/Divide"] = {sid: "adcs_sim_main:42:117:66:57"};
	this.sidHashMap["adcs_sim_main:42:117:66:57"] = {rtwname: "<S3>/Divide"};
	this.rtwnameHashMap["<S3>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:58"};
	this.sidHashMap["adcs_sim_main:42:117:66:58"] = {rtwname: "<S3>/Logical Operator"};
	this.rtwnameHashMap["<S3>/Logical Operator1"] = {sid: "adcs_sim_main:42:117:66:89"};
	this.sidHashMap["adcs_sim_main:42:117:66:89"] = {rtwname: "<S3>/Logical Operator1"};
	this.rtwnameHashMap["<S3>/Mux"] = {sid: "adcs_sim_main:42:117:66:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:59"] = {rtwname: "<S3>/Mux"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "adcs_sim_main:42:117:66:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:60"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Product1"] = {sid: "adcs_sim_main:42:117:66:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:61"] = {rtwname: "<S3>/Product1"};
	this.rtwnameHashMap["<S3>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:62"};
	this.sidHashMap["adcs_sim_main:42:117:66:62"] = {rtwname: "<S3>/Rate Transition"};
	this.rtwnameHashMap["<S3>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:63"};
	this.sidHashMap["adcs_sim_main:42:117:66:63"] = {rtwname: "<S3>/Rate Transition1"};
	this.rtwnameHashMap["<S3>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:64"};
	this.sidHashMap["adcs_sim_main:42:117:66:64"] = {rtwname: "<S3>/Rate Transition2"};
	this.rtwnameHashMap["<S3>/Sum"] = {sid: "adcs_sim_main:42:117:66:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:65"] = {rtwname: "<S3>/Sum"};
	this.rtwnameHashMap["<S3>/Sum1"] = {sid: "adcs_sim_main:42:117:66:66"};
	this.sidHashMap["adcs_sim_main:42:117:66:66"] = {rtwname: "<S3>/Sum1"};
	this.rtwnameHashMap["<S3>/Switch"] = {sid: "adcs_sim_main:42:117:66:67"};
	this.sidHashMap["adcs_sim_main:42:117:66:67"] = {rtwname: "<S3>/Switch"};
	this.rtwnameHashMap["<S3>/Switch1"] = {sid: "adcs_sim_main:42:117:66:68"};
	this.sidHashMap["adcs_sim_main:42:117:66:68"] = {rtwname: "<S3>/Switch1"};
	this.rtwnameHashMap["<S3>/Switch2"] = {sid: "adcs_sim_main:42:117:66:69"};
	this.sidHashMap["adcs_sim_main:42:117:66:69"] = {rtwname: "<S3>/Switch2"};
	this.rtwnameHashMap["<S3>/bias"] = {sid: "adcs_sim_main:42:117:66:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:70"] = {rtwname: "<S3>/bias"};
	this.rtwnameHashMap["<S3>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:71"] = {rtwname: "<S3>/process_matrix"};
	this.rtwnameHashMap["<S3>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:72"] = {rtwname: "<S3>/sensor2body"};
	this.rtwnameHashMap["<S3>/zeros"] = {sid: "adcs_sim_main:42:117:66:73"};
	this.sidHashMap["adcs_sim_main:42:117:66:73"] = {rtwname: "<S3>/zeros"};
	this.rtwnameHashMap["<S3>/zeros "] = {sid: "adcs_sim_main:42:117:66:74"};
	this.sidHashMap["adcs_sim_main:42:117:66:74"] = {rtwname: "<S3>/zeros "};
	this.rtwnameHashMap["<S3>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:75"};
	this.sidHashMap["adcs_sim_main:42:117:66:75"] = {rtwname: "<S3>/mag_body_processed_T"};
	this.rtwnameHashMap["<S4>/sunsensor_angles"] = {sid: "adcs_sim_main:42:117:66:19:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:19"] = {rtwname: "<S4>/sunsensor_angles"};
	this.rtwnameHashMap["<S4>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:117"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:117"] = {rtwname: "<S4>/Data Type Conversion"};
	this.rtwnameHashMap["<S4>/Demux"] = {sid: "adcs_sim_main:42:117:66:19:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:40"] = {rtwname: "<S4>/Demux"};
	this.rtwnameHashMap["<S4>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:116"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:116"] = {rtwname: "<S4>/Logical Operator"};
	this.rtwnameHashMap["<S4>/MATLAB Function"] = {sid: "adcs_sim_main:42:117:66:19:115"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115"] = {rtwname: "<S4>/MATLAB Function"};
	this.rtwnameHashMap["<S4>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:41"] = {rtwname: "<S4>/Mux"};
	this.rtwnameHashMap["<S4>/Product"] = {sid: "adcs_sim_main:42:117:66:19:24"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:24"] = {rtwname: "<S4>/Product"};
	this.rtwnameHashMap["<S4>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:48"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:48"] = {rtwname: "<S4>/Product1"};
	this.rtwnameHashMap["<S4>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:19:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:55"] = {rtwname: "<S4>/Rate Transition1"};
	this.rtwnameHashMap["<S4>/Rate Transition6"] = {sid: "adcs_sim_main:42:117:66:19:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:56"] = {rtwname: "<S4>/Rate Transition6"};
	this.rtwnameHashMap["<S4>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:21"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:21"] = {rtwname: "<S4>/Sum"};
	this.rtwnameHashMap["<S4>/angles_to_vec"] = {sid: "adcs_sim_main:42:117:66:19:83"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:83"] = {rtwname: "<S4>/angles_to_vec"};
	this.rtwnameHashMap["<S4>/bias"] = {sid: "adcs_sim_main:42:117:66:19:22"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:22"] = {rtwname: "<S4>/bias"};
	this.rtwnameHashMap["<S4>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:19:23"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:23"] = {rtwname: "<S4>/process_matrix"};
	this.rtwnameHashMap["<S4>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:19:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:49"] = {rtwname: "<S4>/sensor2body"};
	this.rtwnameHashMap["<S4>/sunsensor_body_processed"] = {sid: "adcs_sim_main:42:117:66:19:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:20"] = {rtwname: "<S4>/sunsensor_body_processed"};
	this.rtwnameHashMap["<S5>:1"] = {sid: "adcs_sim_main:42:117:66:19:115:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115:1"] = {rtwname: "<S5>:1"};
	this.rtwnameHashMap["<S5>:1:4"] = {sid: "adcs_sim_main:42:117:66:19:115:1:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:115:1:4"] = {rtwname: "<S5>:1:4"};
	this.rtwnameHashMap["<S6>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:84"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:84"] = {rtwname: "<S6>/alpha"};
	this.rtwnameHashMap["<S6>/beta"] = {sid: "adcs_sim_main:42:117:66:19:86"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:86"] = {rtwname: "<S6>/beta"};
	this.rtwnameHashMap["<S6>/Abs"] = {sid: "adcs_sim_main:42:117:66:19:101"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:101"] = {rtwname: "<S6>/Abs"};
	this.rtwnameHashMap["<S6>/Abs1"] = {sid: "adcs_sim_main:42:117:66:19:102"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:102"] = {rtwname: "<S6>/Abs1"};
	this.rtwnameHashMap["<S6>/Constant"] = {sid: "adcs_sim_main:42:117:66:19:93"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:93"] = {rtwname: "<S6>/Constant"};
	this.rtwnameHashMap["<S6>/Constant1"] = {sid: "adcs_sim_main:42:117:66:19:112"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:112"] = {rtwname: "<S6>/Constant1"};
	this.rtwnameHashMap["<S6>/Constant2"] = {sid: "adcs_sim_main:42:117:66:19:103"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:103"] = {rtwname: "<S6>/Constant2"};
	this.rtwnameHashMap["<S6>/Constant3"] = {sid: "adcs_sim_main:42:117:66:19:104"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:104"] = {rtwname: "<S6>/Constant3"};
	this.rtwnameHashMap["<S6>/Constant4"] = {sid: "adcs_sim_main:42:117:66:19:105"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:105"] = {rtwname: "<S6>/Constant4"};
	this.rtwnameHashMap["<S6>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:118"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:118"] = {rtwname: "<S6>/Data Type Conversion"};
	this.rtwnameHashMap["<S6>/Data Type Conversion1"] = {sid: "adcs_sim_main:42:117:66:19:119"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:119"] = {rtwname: "<S6>/Data Type Conversion1"};
	this.rtwnameHashMap["<S6>/Data Type Conversion2"] = {sid: "adcs_sim_main:42:117:66:19:120"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:120"] = {rtwname: "<S6>/Data Type Conversion2"};
	this.rtwnameHashMap["<S6>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:106"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:106"] = {rtwname: "<S6>/Logical Operator"};
	this.rtwnameHashMap["<S6>/Math Function"] = {sid: "adcs_sim_main:42:117:66:19:96"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:96"] = {rtwname: "<S6>/Math Function"};
	this.rtwnameHashMap["<S6>/Math Function1"] = {sid: "adcs_sim_main:42:117:66:19:97"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:97"] = {rtwname: "<S6>/Math Function1"};
	this.rtwnameHashMap["<S6>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:95"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:95"] = {rtwname: "<S6>/Mux"};
	this.rtwnameHashMap["<S6>/Saturation"] = {sid: "adcs_sim_main:42:117:66:19:98"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:98"] = {rtwname: "<S6>/Saturation"};
	this.rtwnameHashMap["<S6>/Sqrt"] = {sid: "adcs_sim_main:42:117:66:19:94"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:94"] = {rtwname: "<S6>/Sqrt"};
	this.rtwnameHashMap["<S6>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:90"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:90"] = {rtwname: "<S6>/Sum"};
	this.rtwnameHashMap["<S6>/Switch"] = {sid: "adcs_sim_main:42:117:66:19:107"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:107"] = {rtwname: "<S6>/Switch"};
	this.rtwnameHashMap["<S6>/Switch1"] = {sid: "adcs_sim_main:42:117:66:19:108"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:108"] = {rtwname: "<S6>/Switch1"};
	this.rtwnameHashMap["<S6>/Trigonometric Function"] = {sid: "adcs_sim_main:42:117:66:19:88"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:88"] = {rtwname: "<S6>/Trigonometric Function"};
	this.rtwnameHashMap["<S6>/Trigonometric Function1"] = {sid: "adcs_sim_main:42:117:66:19:89"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:89"] = {rtwname: "<S6>/Trigonometric Function1"};
	this.rtwnameHashMap["<S6>/deg2rad"] = {sid: "adcs_sim_main:42:117:66:19:99"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:99"] = {rtwname: "<S6>/deg2rad"};
	this.rtwnameHashMap["<S6>/deg2rad "] = {sid: "adcs_sim_main:42:117:66:19:100"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:100"] = {rtwname: "<S6>/deg2rad "};
	this.rtwnameHashMap["<S6>/sunsensor_unit_body"] = {sid: "adcs_sim_main:42:117:66:19:85"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:85"] = {rtwname: "<S6>/sunsensor_unit_body"};
	this.rtwnameHashMap["<S6>/sunsensor_angles_in_range"] = {sid: "adcs_sim_main:42:117:66:19:109"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:109"] = {rtwname: "<S6>/sunsensor_angles_in_range"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
