function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S2>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:10"] = "MSP_SP.c:300&MSP_SP.h:60&MSP_SP_data.c:28";
	/* <S2>/Discrete
Transfer Fcn1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:47"] = "MSP_SP.c:285,301,317&MSP_SP.h:51";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:31:9"] = "MSP_SP.c:302";
	/* <S2>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:31:59"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:31:59";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:60"] = "MSP_SP.c:292,315";
	/* <S3>/1 */
	this.urlHashMap["adcs_sim_main:42:117:66:51"] = "MSP_SP.c:383";
	/* <S3>/2 */
	this.urlHashMap["adcs_sim_main:42:117:66:52"] = "MSP_SP.c:384";
	/* <S3>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:53"] = "MSP_SP.c:373";
	/* <S3>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:56"] = "MSP_SP.c:344,353,409,430,451&MSP_SP.h:50";
	/* <S3>/Divide */
	this.urlHashMap["adcs_sim_main:42:117:66:57"] = "MSP_SP.c:410,431,452";
	/* <S3>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:58"] = "MSP_SP.c:374";
	/* <S3>/Logical
Operator1 */
	this.urlHashMap["adcs_sim_main:42:117:66:89"] = "MSP_SP.c:385";
	/* <S3>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:60"] = "MSP_SP.c:351,361";
	/* <S3>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:61"] = "MSP_SP.c:354,363";
	/* <S3>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:62"] = "MSP_SP.c:255,262,269,276&MSP_SP.h:48";
	/* <S3>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:63"] = "MSP_SP.c:349,380";
	/* <S3>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:64"] = "MSP_SP.c:249,283&MSP_SP.h:47";
	/* <S3>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:65"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:65";
	/* <S3>/Sum1 */
	this.urlHashMap["adcs_sim_main:42:117:66:66"] = "MSP_SP.c:411,432,453";
	/* <S3>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:67"] = "MSP_SP.c:402,423,444";
	/* <S3>/Switch1 */
	this.urlHashMap["adcs_sim_main:42:117:66:68"] = "MSP_SP.c:395,416,437";
	/* <S3>/Switch2 */
	this.urlHashMap["adcs_sim_main:42:117:66:69"] = "MSP_SP.c:382,393";
	/* <S3>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:70"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:70";
	/* <S3>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:71"] = "MSP_SP.c:352&MSP_SP.h:61&MSP_SP_data.c:29";
	/* <S3>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:72"] = "MSP_SP.c:366&MSP_SP.h:62&MSP_SP_data.c:30";
	/* <S3>/zeros */
	this.urlHashMap["adcs_sim_main:42:117:66:73"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:73";
	/* <S3>/zeros  */
	this.urlHashMap["adcs_sim_main:42:117:66:74"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:74";
	/* <S4>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:117"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:117";
	/* <S4>/If */
	this.urlHashMap["adcs_sim_main:42:117:66:19:149"] = "MSP_SP.c:519,531,582,619&MSP_SP.h:53";
	/* <S4>/If Action
Subsystem */
	this.urlHashMap["adcs_sim_main:42:117:66:19:170"] = "MSP_SP.c:528,536,539,569,622,626";
	/* <S4>/Merge */
	this.urlHashMap["adcs_sim_main:42:117:66:19:176"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:176";
	/* <S4>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:24"] = "MSP_SP.c:584,596";
	/* <S4>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:48"] = "MSP_SP.c:587,600";
	/* <S4>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:55"] = "MSP_SP.c:308&MSP_SP.h:49";
	/* <S4>/Rate Transition6 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:56"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:56";
	/* <S4>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:21"] = "MSP_SP.c:588";
	/* <S4>/Switch Case Action
Subsystem */
	this.urlHashMap["adcs_sim_main:42:117:66:19:163"] = "MSP_SP.c:573,578";
	/* <S4>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:19:22"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:22";
	/* <S4>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:19:23"] = "MSP_SP.c:585&MSP_SP.h:63&MSP_SP_data.c:31";
	/* <S4>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:19:49"] = "MSP_SP.c:599&MSP_SP.h:68&MSP_SP_data.c:36";
	/* <S5>/Action Port */
	this.urlHashMap["adcs_sim_main:42:117:66:19:172"] = "MSP_SP.c:529,540";
	/* <S5>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:202"] = "MSP_SP.c:547";
	/* <S5>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:19:203"] = "MSP_SP.c:542,564";
	/* <S5>/Unit Delay */
	this.urlHashMap["adcs_sim_main:42:117:66:19:204"] = "MSP_SP.c:532,554,566,623&MSP_SP.h:52";
	/* <S6>/ss_flag */
	this.urlHashMap["adcs_sim_main:42:117:66:19:164"] = "MSP_SP.c:520";
	/* <S6>/Action Port */
	this.urlHashMap["adcs_sim_main:42:117:66:19:165"] = "MSP_SP.c:574";
	/* <S7>/Constant */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:32"] = "MSP_SP.c:484";
	/* <S7>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:33"] = "MSP_SP.c:586";
	/* <S7>/Data Type Conversion1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:34"] = "MSP_SP.c:513";
	/* <S7>/Data Type Conversion2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:35"] = "MSP_SP.c:507";
	/* <S7>/Math
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:36"] = "MSP_SP.c:485";
	/* <S7>/Math
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:37"] = "MSP_SP.c:486";
	/* <S7>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:39"] = "MSP_SP.c:514";
	/* <S7>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:40"] = "MSP_SP.c:508";
	/* <S7>/Reciprocal
Sqrt */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:41"] = "MSP_SP.c:492,505";
	/* <S7>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:42"] = "MSP_SP.c:483";
	/* <S7>/Trigonometric
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:43"] = "MSP_SP.c:471";
	/* <S7>/Trigonometric
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:44"] = "MSP_SP.c:477";
	/* <S7>/deg2rad */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:45"] = "MSP_SP.c:472";
	/* <S7>/deg2rad  */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:46"] = "MSP_SP.c:478";
	/* <S8>/AND */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:2"] = "MSP_SP.c:548";
	/* <S8>/FixPt
Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:3"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:200:3";
	/* <S8>/Lower Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:4"] = "MSP_SP.c:543";
	/* <S8>/Lower Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:5"] = "MSP_SP.c:550";
	/* <S8>/Upper Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:6"] = "MSP_SP.c:544";
	/* <S8>/Upper Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:7"] = "MSP_SP.c:551";
	/* <S9>/AND */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:2"] = "MSP_SP.c:549";
	/* <S9>/FixPt
Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:3"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:201:3";
	/* <S9>/Lower Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:4"] = "MSP_SP.c:545";
	/* <S9>/Lower Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:5"] = "MSP_SP.c:552";
	/* <S9>/Upper Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:6"] = "MSP_SP.c:546";
	/* <S9>/Upper Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:7"] = "MSP_SP.c:553";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_SP"};
	this.sidHashMap["MSP_SP"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:117:66"};
	this.sidHashMap["adcs_sim_main:42:117:66"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "adcs_sim_main:42:117:66:19:170"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:170"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "adcs_sim_main:42:117:66:19:163"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:163"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "adcs_sim_main:42:117:66:19:122"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<S8>"] = {sid: "adcs_sim_main:42:117:66:19:200"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200"] = {rtwname: "<S8>"};
	this.rtwnameHashMap["<S9>"] = {sid: "adcs_sim_main:42:117:66:19:201"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201"] = {rtwname: "<S9>"};
	this.rtwnameHashMap["<S1>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:33"] = {rtwname: "<S1>/mag1_body_T"};
	this.rtwnameHashMap["<S1>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:37"] = {rtwname: "<S1>/mag2_body_T"};
	this.rtwnameHashMap["<S1>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:34"] = {rtwname: "<S1>/omega_radps_gyro"};
	this.rtwnameHashMap["<S1>/sun_vec_body_angles"] = {sid: "adcs_sim_main:42:117:66:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:4"] = {rtwname: "<S1>/sun_vec_body_angles"};
	this.rtwnameHashMap["<S1>/gyro_processing_lib"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S1>/gyro_processing_lib"};
	this.rtwnameHashMap["<S1>/magnetometer_processing_lib"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S1>/magnetometer_processing_lib"};
	this.rtwnameHashMap["<S1>/sunsensor_processing_lib"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S1>/sunsensor_processing_lib"};
	this.rtwnameHashMap["<S1>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:35"] = {rtwname: "<S1>/mag_body_processed_T"};
	this.rtwnameHashMap["<S1>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:36"] = {rtwname: "<S1>/omega_radps_processed"};
	this.rtwnameHashMap["<S1>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:20"] = {rtwname: "<S1>/sun_vec_body"};
	this.rtwnameHashMap["<S2>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:31:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:5"] = {rtwname: "<S2>/omega_radps_gyro"};
	this.rtwnameHashMap["<S2>/Constant1"] = {sid: "adcs_sim_main:42:117:66:31:10"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:10"] = {rtwname: "<S2>/Constant1"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:117:66:31:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:78"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn1"] = {sid: "adcs_sim_main:42:117:66:31:47"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:47"] = {rtwname: "<S2>/Discrete Transfer Fcn1"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:117:66:31:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:80"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:117:66:31:9"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:9"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:31:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:59"] = {rtwname: "<S2>/Rate Transition"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:31:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:60"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:31:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:6"] = {rtwname: "<S2>/omega_radps_processed"};
	this.rtwnameHashMap["<S3>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:49"] = {rtwname: "<S3>/mag1_body_T"};
	this.rtwnameHashMap["<S3>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:50"};
	this.sidHashMap["adcs_sim_main:42:117:66:50"] = {rtwname: "<S3>/mag2_body_T"};
	this.rtwnameHashMap["<S3>/1"] = {sid: "adcs_sim_main:42:117:66:51"};
	this.sidHashMap["adcs_sim_main:42:117:66:51"] = {rtwname: "<S3>/1"};
	this.rtwnameHashMap["<S3>/2"] = {sid: "adcs_sim_main:42:117:66:52"};
	this.sidHashMap["adcs_sim_main:42:117:66:52"] = {rtwname: "<S3>/2"};
	this.rtwnameHashMap["<S3>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:53"};
	this.sidHashMap["adcs_sim_main:42:117:66:53"] = {rtwname: "<S3>/Data Type Conversion"};
	this.rtwnameHashMap["<S3>/Demux1"] = {sid: "adcs_sim_main:42:117:66:54"};
	this.sidHashMap["adcs_sim_main:42:117:66:54"] = {rtwname: "<S3>/Demux1"};
	this.rtwnameHashMap["<S3>/Demux2"] = {sid: "adcs_sim_main:42:117:66:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:55"] = {rtwname: "<S3>/Demux2"};
	this.rtwnameHashMap["<S3>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:56"] = {rtwname: "<S3>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S3>/Divide"] = {sid: "adcs_sim_main:42:117:66:57"};
	this.sidHashMap["adcs_sim_main:42:117:66:57"] = {rtwname: "<S3>/Divide"};
	this.rtwnameHashMap["<S3>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:58"};
	this.sidHashMap["adcs_sim_main:42:117:66:58"] = {rtwname: "<S3>/Logical Operator"};
	this.rtwnameHashMap["<S3>/Logical Operator1"] = {sid: "adcs_sim_main:42:117:66:89"};
	this.sidHashMap["adcs_sim_main:42:117:66:89"] = {rtwname: "<S3>/Logical Operator1"};
	this.rtwnameHashMap["<S3>/Mux"] = {sid: "adcs_sim_main:42:117:66:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:59"] = {rtwname: "<S3>/Mux"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "adcs_sim_main:42:117:66:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:60"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Product1"] = {sid: "adcs_sim_main:42:117:66:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:61"] = {rtwname: "<S3>/Product1"};
	this.rtwnameHashMap["<S3>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:62"};
	this.sidHashMap["adcs_sim_main:42:117:66:62"] = {rtwname: "<S3>/Rate Transition"};
	this.rtwnameHashMap["<S3>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:63"};
	this.sidHashMap["adcs_sim_main:42:117:66:63"] = {rtwname: "<S3>/Rate Transition1"};
	this.rtwnameHashMap["<S3>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:64"};
	this.sidHashMap["adcs_sim_main:42:117:66:64"] = {rtwname: "<S3>/Rate Transition2"};
	this.rtwnameHashMap["<S3>/Sum"] = {sid: "adcs_sim_main:42:117:66:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:65"] = {rtwname: "<S3>/Sum"};
	this.rtwnameHashMap["<S3>/Sum1"] = {sid: "adcs_sim_main:42:117:66:66"};
	this.sidHashMap["adcs_sim_main:42:117:66:66"] = {rtwname: "<S3>/Sum1"};
	this.rtwnameHashMap["<S3>/Switch"] = {sid: "adcs_sim_main:42:117:66:67"};
	this.sidHashMap["adcs_sim_main:42:117:66:67"] = {rtwname: "<S3>/Switch"};
	this.rtwnameHashMap["<S3>/Switch1"] = {sid: "adcs_sim_main:42:117:66:68"};
	this.sidHashMap["adcs_sim_main:42:117:66:68"] = {rtwname: "<S3>/Switch1"};
	this.rtwnameHashMap["<S3>/Switch2"] = {sid: "adcs_sim_main:42:117:66:69"};
	this.sidHashMap["adcs_sim_main:42:117:66:69"] = {rtwname: "<S3>/Switch2"};
	this.rtwnameHashMap["<S3>/bias"] = {sid: "adcs_sim_main:42:117:66:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:70"] = {rtwname: "<S3>/bias"};
	this.rtwnameHashMap["<S3>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:71"] = {rtwname: "<S3>/process_matrix"};
	this.rtwnameHashMap["<S3>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:72"] = {rtwname: "<S3>/sensor2body"};
	this.rtwnameHashMap["<S3>/zeros"] = {sid: "adcs_sim_main:42:117:66:73"};
	this.sidHashMap["adcs_sim_main:42:117:66:73"] = {rtwname: "<S3>/zeros"};
	this.rtwnameHashMap["<S3>/zeros "] = {sid: "adcs_sim_main:42:117:66:74"};
	this.sidHashMap["adcs_sim_main:42:117:66:74"] = {rtwname: "<S3>/zeros "};
	this.rtwnameHashMap["<S3>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:75"};
	this.sidHashMap["adcs_sim_main:42:117:66:75"] = {rtwname: "<S3>/mag_body_processed_T"};
	this.rtwnameHashMap["<S4>/sunsensor_angles"] = {sid: "adcs_sim_main:42:117:66:19:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:19"] = {rtwname: "<S4>/sunsensor_angles"};
	this.rtwnameHashMap["<S4>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:117"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:117"] = {rtwname: "<S4>/Data Type Conversion"};
	this.rtwnameHashMap["<S4>/Demux"] = {sid: "adcs_sim_main:42:117:66:19:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:40"] = {rtwname: "<S4>/Demux"};
	this.rtwnameHashMap["<S4>/If"] = {sid: "adcs_sim_main:42:117:66:19:149"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:149"] = {rtwname: "<S4>/If"};
	this.rtwnameHashMap["<S4>/If Action Subsystem"] = {sid: "adcs_sim_main:42:117:66:19:170"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:170"] = {rtwname: "<S4>/If Action Subsystem"};
	this.rtwnameHashMap["<S4>/Merge"] = {sid: "adcs_sim_main:42:117:66:19:176"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:176"] = {rtwname: "<S4>/Merge"};
	this.rtwnameHashMap["<S4>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:41"] = {rtwname: "<S4>/Mux"};
	this.rtwnameHashMap["<S4>/Product"] = {sid: "adcs_sim_main:42:117:66:19:24"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:24"] = {rtwname: "<S4>/Product"};
	this.rtwnameHashMap["<S4>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:48"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:48"] = {rtwname: "<S4>/Product1"};
	this.rtwnameHashMap["<S4>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:19:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:55"] = {rtwname: "<S4>/Rate Transition1"};
	this.rtwnameHashMap["<S4>/Rate Transition6"] = {sid: "adcs_sim_main:42:117:66:19:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:56"] = {rtwname: "<S4>/Rate Transition6"};
	this.rtwnameHashMap["<S4>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:21"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:21"] = {rtwname: "<S4>/Sum"};
	this.rtwnameHashMap["<S4>/Switch Case Action Subsystem"] = {sid: "adcs_sim_main:42:117:66:19:163"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:163"] = {rtwname: "<S4>/Switch Case Action Subsystem"};
	this.rtwnameHashMap["<S4>/angles_to_vec"] = {sid: "adcs_sim_main:42:117:66:19:122"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122"] = {rtwname: "<S4>/angles_to_vec"};
	this.rtwnameHashMap["<S4>/bias"] = {sid: "adcs_sim_main:42:117:66:19:22"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:22"] = {rtwname: "<S4>/bias"};
	this.rtwnameHashMap["<S4>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:19:23"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:23"] = {rtwname: "<S4>/process_matrix"};
	this.rtwnameHashMap["<S4>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:19:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:49"] = {rtwname: "<S4>/sensor2body"};
	this.rtwnameHashMap["<S4>/sunsensor_body_processed"] = {sid: "adcs_sim_main:42:117:66:19:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:20"] = {rtwname: "<S4>/sunsensor_body_processed"};
	this.rtwnameHashMap["<S5>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:197"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:197"] = {rtwname: "<S5>/alpha"};
	this.rtwnameHashMap["<S5>/beta"] = {sid: "adcs_sim_main:42:117:66:19:198"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:198"] = {rtwname: "<S5>/beta"};
	this.rtwnameHashMap["<S5>/ss_flag"] = {sid: "adcs_sim_main:42:117:66:19:199"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:199"] = {rtwname: "<S5>/ss_flag"};
	this.rtwnameHashMap["<S5>/Action Port"] = {sid: "adcs_sim_main:42:117:66:19:172"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:172"] = {rtwname: "<S5>/Action Port"};
	this.rtwnameHashMap["<S5>/Interval Test"] = {sid: "adcs_sim_main:42:117:66:19:200"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200"] = {rtwname: "<S5>/Interval Test"};
	this.rtwnameHashMap["<S5>/Interval Test1"] = {sid: "adcs_sim_main:42:117:66:19:201"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201"] = {rtwname: "<S5>/Interval Test1"};
	this.rtwnameHashMap["<S5>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:202"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:202"] = {rtwname: "<S5>/Logical Operator"};
	this.rtwnameHashMap["<S5>/Switch"] = {sid: "adcs_sim_main:42:117:66:19:203"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:203"] = {rtwname: "<S5>/Switch"};
	this.rtwnameHashMap["<S5>/Unit Delay"] = {sid: "adcs_sim_main:42:117:66:19:204"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:204"] = {rtwname: "<S5>/Unit Delay"};
	this.rtwnameHashMap["<S5>/ss_flag_out"] = {sid: "adcs_sim_main:42:117:66:19:173"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:173"] = {rtwname: "<S5>/ss_flag_out"};
	this.rtwnameHashMap["<S6>/ss_flag"] = {sid: "adcs_sim_main:42:117:66:19:164"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:164"] = {rtwname: "<S6>/ss_flag"};
	this.rtwnameHashMap["<S6>/Action Port"] = {sid: "adcs_sim_main:42:117:66:19:165"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:165"] = {rtwname: "<S6>/Action Port"};
	this.rtwnameHashMap["<S6>/ss_flag_out"] = {sid: "adcs_sim_main:42:117:66:19:166"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:166"] = {rtwname: "<S6>/ss_flag_out"};
	this.rtwnameHashMap["<S7>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:122:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:2"] = {rtwname: "<S7>/alpha"};
	this.rtwnameHashMap["<S7>/beta"] = {sid: "adcs_sim_main:42:117:66:19:122:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:3"] = {rtwname: "<S7>/beta"};
	this.rtwnameHashMap["<S7>/Constant"] = {sid: "adcs_sim_main:42:117:66:19:122:32"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:32"] = {rtwname: "<S7>/Constant"};
	this.rtwnameHashMap["<S7>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:122:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:33"] = {rtwname: "<S7>/Data Type Conversion"};
	this.rtwnameHashMap["<S7>/Data Type Conversion1"] = {sid: "adcs_sim_main:42:117:66:19:122:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:34"] = {rtwname: "<S7>/Data Type Conversion1"};
	this.rtwnameHashMap["<S7>/Data Type Conversion2"] = {sid: "adcs_sim_main:42:117:66:19:122:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:35"] = {rtwname: "<S7>/Data Type Conversion2"};
	this.rtwnameHashMap["<S7>/Math Function"] = {sid: "adcs_sim_main:42:117:66:19:122:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:36"] = {rtwname: "<S7>/Math Function"};
	this.rtwnameHashMap["<S7>/Math Function1"] = {sid: "adcs_sim_main:42:117:66:19:122:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:37"] = {rtwname: "<S7>/Math Function1"};
	this.rtwnameHashMap["<S7>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:122:38"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:38"] = {rtwname: "<S7>/Mux"};
	this.rtwnameHashMap["<S7>/Product"] = {sid: "adcs_sim_main:42:117:66:19:122:39"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:39"] = {rtwname: "<S7>/Product"};
	this.rtwnameHashMap["<S7>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:122:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:40"] = {rtwname: "<S7>/Product1"};
	this.rtwnameHashMap["<S7>/Reciprocal Sqrt"] = {sid: "adcs_sim_main:42:117:66:19:122:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:41"] = {rtwname: "<S7>/Reciprocal Sqrt"};
	this.rtwnameHashMap["<S7>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:122:42"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:42"] = {rtwname: "<S7>/Sum"};
	this.rtwnameHashMap["<S7>/Trigonometric Function"] = {sid: "adcs_sim_main:42:117:66:19:122:43"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:43"] = {rtwname: "<S7>/Trigonometric Function"};
	this.rtwnameHashMap["<S7>/Trigonometric Function1"] = {sid: "adcs_sim_main:42:117:66:19:122:44"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:44"] = {rtwname: "<S7>/Trigonometric Function1"};
	this.rtwnameHashMap["<S7>/deg2rad"] = {sid: "adcs_sim_main:42:117:66:19:122:45"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:45"] = {rtwname: "<S7>/deg2rad"};
	this.rtwnameHashMap["<S7>/deg2rad "] = {sid: "adcs_sim_main:42:117:66:19:122:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:46"] = {rtwname: "<S7>/deg2rad "};
	this.rtwnameHashMap["<S7>/sunsensor_unit_body"] = {sid: "adcs_sim_main:42:117:66:19:122:16"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:16"] = {rtwname: "<S7>/sunsensor_unit_body"};
	this.rtwnameHashMap["<S8>/u"] = {sid: "adcs_sim_main:42:117:66:19:200:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:1"] = {rtwname: "<S8>/u"};
	this.rtwnameHashMap["<S8>/AND"] = {sid: "adcs_sim_main:42:117:66:19:200:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:2"] = {rtwname: "<S8>/AND"};
	this.rtwnameHashMap["<S8>/FixPt Data Type Duplicate"] = {sid: "adcs_sim_main:42:117:66:19:200:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:3"] = {rtwname: "<S8>/FixPt Data Type Duplicate"};
	this.rtwnameHashMap["<S8>/Lower Limit"] = {sid: "adcs_sim_main:42:117:66:19:200:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:4"] = {rtwname: "<S8>/Lower Limit"};
	this.rtwnameHashMap["<S8>/Lower Test"] = {sid: "adcs_sim_main:42:117:66:19:200:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:5"] = {rtwname: "<S8>/Lower Test"};
	this.rtwnameHashMap["<S8>/Upper Limit"] = {sid: "adcs_sim_main:42:117:66:19:200:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:6"] = {rtwname: "<S8>/Upper Limit"};
	this.rtwnameHashMap["<S8>/Upper Test"] = {sid: "adcs_sim_main:42:117:66:19:200:7"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:7"] = {rtwname: "<S8>/Upper Test"};
	this.rtwnameHashMap["<S8>/y"] = {sid: "adcs_sim_main:42:117:66:19:200:8"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:8"] = {rtwname: "<S8>/y"};
	this.rtwnameHashMap["<S9>/u"] = {sid: "adcs_sim_main:42:117:66:19:201:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:1"] = {rtwname: "<S9>/u"};
	this.rtwnameHashMap["<S9>/AND"] = {sid: "adcs_sim_main:42:117:66:19:201:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:2"] = {rtwname: "<S9>/AND"};
	this.rtwnameHashMap["<S9>/FixPt Data Type Duplicate"] = {sid: "adcs_sim_main:42:117:66:19:201:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:3"] = {rtwname: "<S9>/FixPt Data Type Duplicate"};
	this.rtwnameHashMap["<S9>/Lower Limit"] = {sid: "adcs_sim_main:42:117:66:19:201:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:4"] = {rtwname: "<S9>/Lower Limit"};
	this.rtwnameHashMap["<S9>/Lower Test"] = {sid: "adcs_sim_main:42:117:66:19:201:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:5"] = {rtwname: "<S9>/Lower Test"};
	this.rtwnameHashMap["<S9>/Upper Limit"] = {sid: "adcs_sim_main:42:117:66:19:201:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:6"] = {rtwname: "<S9>/Upper Limit"};
	this.rtwnameHashMap["<S9>/Upper Test"] = {sid: "adcs_sim_main:42:117:66:19:201:7"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:7"] = {rtwname: "<S9>/Upper Test"};
	this.rtwnameHashMap["<S9>/y"] = {sid: "adcs_sim_main:42:117:66:19:201:8"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:8"] = {rtwname: "<S9>/y"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
