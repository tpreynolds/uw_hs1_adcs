function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S2>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:10"] = "MSP_SP.c:300&MSP_SP.h:61&MSP_SP_data.c:28";
	/* <S2>/Discrete
Transfer Fcn1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:47"] = "MSP_SP.c:285,301,317&MSP_SP.h:52";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:31:9"] = "MSP_SP.c:302";
	/* <S2>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:31:59"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:31:59";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:31:60"] = "MSP_SP.c:292,315";
	/* <S3>/Rate Transition */
	this.urlHashMap["adcs_sim_main:42:117:66:62"] = "MSP_SP.c:255,262,269,276&MSP_SP.h:48";
	/* <S3>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:63"] = "MSP_SP.c:401,407";
	/* <S3>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:117:66:64"] = "MSP_SP.c:249,283&MSP_SP.h:47";
	/* <S3>/Rate Transition3 */
	this.urlHashMap["adcs_sim_main:42:117:66:98"] = "MSP_SP.c:376,412";
	/* <S4>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:117"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:117";
	/* <S4>/If */
	this.urlHashMap["adcs_sim_main:42:117:66:19:149"] = "MSP_SP.c:491,503,554,591&MSP_SP.h:54";
	/* <S4>/If Action
Subsystem */
	this.urlHashMap["adcs_sim_main:42:117:66:19:170"] = "MSP_SP.c:500,508,511,541,594,598";
	/* <S4>/Merge */
	this.urlHashMap["adcs_sim_main:42:117:66:19:176"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:176";
	/* <S4>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:24"] = "MSP_SP.c:556,568";
	/* <S4>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:48"] = "MSP_SP.c:559,572";
	/* <S4>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:55"] = "MSP_SP.c:308&MSP_SP.h:49";
	/* <S4>/Rate Transition6 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:56"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:56";
	/* <S4>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:21"] = "MSP_SP.c:560";
	/* <S4>/Switch Case Action
Subsystem */
	this.urlHashMap["adcs_sim_main:42:117:66:19:163"] = "MSP_SP.c:545,550";
	/* <S4>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:19:22"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:19:22";
	/* <S4>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:19:23"] = "MSP_SP.c:557&MSP_SP.h:62&MSP_SP_data.c:29";
	/* <S4>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:19:49"] = "MSP_SP.c:571&MSP_SP.h:71&MSP_SP_data.c:38";
	/* <S5>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:53"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:53";
	/* <S5>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:56"] = "MSP_SP.c:344,351,414&MSP_SP.h:50";
	/* <S5>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:60"] = "MSP_SP.c:349,358";
	/* <S5>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:61"] = "MSP_SP.c:360,369";
	/* <S5>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:65"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:65";
	/* <S5>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:70"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:70";
	/* <S5>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:71"] = "MSP_SP.c:350&MSP_SP.h:63&MSP_SP_data.c:30";
	/* <S5>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:72"] = "MSP_SP.c:361&MSP_SP.h:64&MSP_SP_data.c:31";
	/* <S6>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:97:53"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:97:53";
	/* <S6>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:117:66:97:56"] = "MSP_SP.c:371,380,422&MSP_SP.h:51";
	/* <S6>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:97:60"] = "MSP_SP.c:378,388";
	/* <S6>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:97:61"] = "MSP_SP.c:381,395";
	/* <S6>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:97:65"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:97:65";
	/* <S6>/bias */
	this.urlHashMap["adcs_sim_main:42:117:66:97:70"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:117:66:97:70";
	/* <S6>/process_matrix */
	this.urlHashMap["adcs_sim_main:42:117:66:97:71"] = "MSP_SP.c:379&MSP_SP.h:65&MSP_SP_data.c:32";
	/* <S6>/sensor2body */
	this.urlHashMap["adcs_sim_main:42:117:66:97:72"] = "MSP_SP.c:394&MSP_SP.h:66&MSP_SP_data.c:33";
	/* <S7>/Action Port */
	this.urlHashMap["adcs_sim_main:42:117:66:19:172"] = "MSP_SP.c:501,512";
	/* <S7>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:117:66:19:202"] = "MSP_SP.c:521";
	/* <S7>/Switch */
	this.urlHashMap["adcs_sim_main:42:117:66:19:203"] = "MSP_SP.c:514,536";
	/* <S7>/Unit Delay */
	this.urlHashMap["adcs_sim_main:42:117:66:19:204"] = "MSP_SP.c:504,526,538,595&MSP_SP.h:53";
	/* <S8>/ss_flag */
	this.urlHashMap["adcs_sim_main:42:117:66:19:164"] = "MSP_SP.c:492";
	/* <S8>/Action Port */
	this.urlHashMap["adcs_sim_main:42:117:66:19:165"] = "MSP_SP.c:546";
	/* <S9>/Constant */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:32"] = "MSP_SP.c:456";
	/* <S9>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:33"] = "MSP_SP.c:558";
	/* <S9>/Data Type Conversion1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:34"] = "MSP_SP.c:485";
	/* <S9>/Data Type Conversion2 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:35"] = "MSP_SP.c:479";
	/* <S9>/Math
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:36"] = "MSP_SP.c:457";
	/* <S9>/Math
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:37"] = "MSP_SP.c:458";
	/* <S9>/Product */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:39"] = "MSP_SP.c:486";
	/* <S9>/Product1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:40"] = "MSP_SP.c:480";
	/* <S9>/Reciprocal
Sqrt */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:41"] = "MSP_SP.c:464,477";
	/* <S9>/Sum */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:42"] = "MSP_SP.c:455";
	/* <S9>/Trigonometric
Function */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:43"] = "MSP_SP.c:443";
	/* <S9>/Trigonometric
Function1 */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:44"] = "MSP_SP.c:449";
	/* <S9>/deg2rad */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:45"] = "MSP_SP.c:444";
	/* <S9>/deg2rad  */
	this.urlHashMap["adcs_sim_main:42:117:66:19:122:46"] = "MSP_SP.c:450";
	/* <S10>/AND */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:2"] = "MSP_SP.c:519";
	/* <S10>/FixPt
Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:3"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:200:3";
	/* <S10>/Lower Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:4"] = "MSP_SP.c:515";
	/* <S10>/Lower Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:5"] = "MSP_SP.c:522";
	/* <S10>/Upper Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:6"] = "MSP_SP.c:516";
	/* <S10>/Upper Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:200:7"] = "MSP_SP.c:523";
	/* <S11>/AND */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:2"] = "MSP_SP.c:520";
	/* <S11>/FixPt
Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:3"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:117:66:19:201:3";
	/* <S11>/Lower Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:4"] = "MSP_SP.c:517";
	/* <S11>/Lower Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:5"] = "MSP_SP.c:524";
	/* <S11>/Upper Limit */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:6"] = "MSP_SP.c:518";
	/* <S11>/Upper Test */
	this.urlHashMap["adcs_sim_main:42:117:66:19:201:7"] = "MSP_SP.c:525";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_SP"};
	this.sidHashMap["MSP_SP"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:117:66"};
	this.sidHashMap["adcs_sim_main:42:117:66"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "adcs_sim_main:42:117:66:90"};
	this.sidHashMap["adcs_sim_main:42:117:66:90"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "adcs_sim_main:42:117:66:97"};
	this.sidHashMap["adcs_sim_main:42:117:66:97"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "adcs_sim_main:42:117:66:19:170"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:170"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<S8>"] = {sid: "adcs_sim_main:42:117:66:19:163"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:163"] = {rtwname: "<S8>"};
	this.rtwnameHashMap["<S9>"] = {sid: "adcs_sim_main:42:117:66:19:122"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122"] = {rtwname: "<S9>"};
	this.rtwnameHashMap["<S10>"] = {sid: "adcs_sim_main:42:117:66:19:200"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200"] = {rtwname: "<S10>"};
	this.rtwnameHashMap["<S11>"] = {sid: "adcs_sim_main:42:117:66:19:201"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201"] = {rtwname: "<S11>"};
	this.rtwnameHashMap["<S1>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:33"] = {rtwname: "<S1>/mag1_body_T"};
	this.rtwnameHashMap["<S1>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:37"] = {rtwname: "<S1>/mag2_body_T"};
	this.rtwnameHashMap["<S1>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:34"] = {rtwname: "<S1>/omega_radps_gyro"};
	this.rtwnameHashMap["<S1>/sun_vec_body_angles"] = {sid: "adcs_sim_main:42:117:66:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:4"] = {rtwname: "<S1>/sun_vec_body_angles"};
	this.rtwnameHashMap["<S1>/gyro_processing_lib"] = {sid: "adcs_sim_main:42:117:66:31"};
	this.sidHashMap["adcs_sim_main:42:117:66:31"] = {rtwname: "<S1>/gyro_processing_lib"};
	this.rtwnameHashMap["<S1>/magnetometer_processing_lib"] = {sid: "adcs_sim_main:42:117:66:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:46"] = {rtwname: "<S1>/magnetometer_processing_lib"};
	this.rtwnameHashMap["<S1>/sunsensor_processing_lib"] = {sid: "adcs_sim_main:42:117:66:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19"] = {rtwname: "<S1>/sunsensor_processing_lib"};
	this.rtwnameHashMap["<S1>/mag1_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:35"] = {rtwname: "<S1>/mag1_body_processed_T"};
	this.rtwnameHashMap["<S1>/mag2_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:100"};
	this.sidHashMap["adcs_sim_main:42:117:66:100"] = {rtwname: "<S1>/mag2_body_processed_T"};
	this.rtwnameHashMap["<S1>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:36"] = {rtwname: "<S1>/omega_radps_processed"};
	this.rtwnameHashMap["<S1>/sun_vec_body"] = {sid: "adcs_sim_main:42:117:66:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:20"] = {rtwname: "<S1>/sun_vec_body"};
	this.rtwnameHashMap["<S2>/omega_radps_gyro"] = {sid: "adcs_sim_main:42:117:66:31:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:5"] = {rtwname: "<S2>/omega_radps_gyro"};
	this.rtwnameHashMap["<S2>/Constant1"] = {sid: "adcs_sim_main:42:117:66:31:10"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:10"] = {rtwname: "<S2>/Constant1"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:117:66:31:78"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:78"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn1"] = {sid: "adcs_sim_main:42:117:66:31:47"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:47"] = {rtwname: "<S2>/Discrete Transfer Fcn1"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:117:66:31:80"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:80"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:117:66:31:9"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:9"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:31:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:59"] = {rtwname: "<S2>/Rate Transition"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:31:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:60"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/omega_radps_processed"] = {sid: "adcs_sim_main:42:117:66:31:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:31:6"] = {rtwname: "<S2>/omega_radps_processed"};
	this.rtwnameHashMap["<S3>/mag1_body_T"] = {sid: "adcs_sim_main:42:117:66:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:49"] = {rtwname: "<S3>/mag1_body_T"};
	this.rtwnameHashMap["<S3>/mag2_body_T"] = {sid: "adcs_sim_main:42:117:66:50"};
	this.sidHashMap["adcs_sim_main:42:117:66:50"] = {rtwname: "<S3>/mag2_body_T"};
	this.rtwnameHashMap["<S3>/Rate Transition"] = {sid: "adcs_sim_main:42:117:66:62"};
	this.sidHashMap["adcs_sim_main:42:117:66:62"] = {rtwname: "<S3>/Rate Transition"};
	this.rtwnameHashMap["<S3>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:63"};
	this.sidHashMap["adcs_sim_main:42:117:66:63"] = {rtwname: "<S3>/Rate Transition1"};
	this.rtwnameHashMap["<S3>/Rate Transition2"] = {sid: "adcs_sim_main:42:117:66:64"};
	this.sidHashMap["adcs_sim_main:42:117:66:64"] = {rtwname: "<S3>/Rate Transition2"};
	this.rtwnameHashMap["<S3>/Rate Transition3"] = {sid: "adcs_sim_main:42:117:66:98"};
	this.sidHashMap["adcs_sim_main:42:117:66:98"] = {rtwname: "<S3>/Rate Transition3"};
	this.rtwnameHashMap["<S3>/mag_processing1 "] = {sid: "adcs_sim_main:42:117:66:90"};
	this.sidHashMap["adcs_sim_main:42:117:66:90"] = {rtwname: "<S3>/mag_processing1 "};
	this.rtwnameHashMap["<S3>/mag_processing2"] = {sid: "adcs_sim_main:42:117:66:97"};
	this.sidHashMap["adcs_sim_main:42:117:66:97"] = {rtwname: "<S3>/mag_processing2"};
	this.rtwnameHashMap["<S3>/mag1_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:75"};
	this.sidHashMap["adcs_sim_main:42:117:66:75"] = {rtwname: "<S3>/mag1_body_processed_T"};
	this.rtwnameHashMap["<S3>/mag2_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:99"};
	this.sidHashMap["adcs_sim_main:42:117:66:99"] = {rtwname: "<S3>/mag2_body_processed_T"};
	this.rtwnameHashMap["<S4>/sunsensor_angles"] = {sid: "adcs_sim_main:42:117:66:19:19"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:19"] = {rtwname: "<S4>/sunsensor_angles"};
	this.rtwnameHashMap["<S4>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:117"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:117"] = {rtwname: "<S4>/Data Type Conversion"};
	this.rtwnameHashMap["<S4>/Demux"] = {sid: "adcs_sim_main:42:117:66:19:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:40"] = {rtwname: "<S4>/Demux"};
	this.rtwnameHashMap["<S4>/If"] = {sid: "adcs_sim_main:42:117:66:19:149"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:149"] = {rtwname: "<S4>/If"};
	this.rtwnameHashMap["<S4>/If Action Subsystem"] = {sid: "adcs_sim_main:42:117:66:19:170"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:170"] = {rtwname: "<S4>/If Action Subsystem"};
	this.rtwnameHashMap["<S4>/Merge"] = {sid: "adcs_sim_main:42:117:66:19:176"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:176"] = {rtwname: "<S4>/Merge"};
	this.rtwnameHashMap["<S4>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:41"] = {rtwname: "<S4>/Mux"};
	this.rtwnameHashMap["<S4>/Product"] = {sid: "adcs_sim_main:42:117:66:19:24"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:24"] = {rtwname: "<S4>/Product"};
	this.rtwnameHashMap["<S4>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:48"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:48"] = {rtwname: "<S4>/Product1"};
	this.rtwnameHashMap["<S4>/Rate Transition1"] = {sid: "adcs_sim_main:42:117:66:19:55"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:55"] = {rtwname: "<S4>/Rate Transition1"};
	this.rtwnameHashMap["<S4>/Rate Transition6"] = {sid: "adcs_sim_main:42:117:66:19:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:56"] = {rtwname: "<S4>/Rate Transition6"};
	this.rtwnameHashMap["<S4>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:21"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:21"] = {rtwname: "<S4>/Sum"};
	this.rtwnameHashMap["<S4>/Switch Case Action Subsystem"] = {sid: "adcs_sim_main:42:117:66:19:163"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:163"] = {rtwname: "<S4>/Switch Case Action Subsystem"};
	this.rtwnameHashMap["<S4>/angles_to_vec"] = {sid: "adcs_sim_main:42:117:66:19:122"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122"] = {rtwname: "<S4>/angles_to_vec"};
	this.rtwnameHashMap["<S4>/bias"] = {sid: "adcs_sim_main:42:117:66:19:22"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:22"] = {rtwname: "<S4>/bias"};
	this.rtwnameHashMap["<S4>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:19:23"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:23"] = {rtwname: "<S4>/process_matrix"};
	this.rtwnameHashMap["<S4>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:19:49"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:49"] = {rtwname: "<S4>/sensor2body"};
	this.rtwnameHashMap["<S4>/sunsensor_body_processed"] = {sid: "adcs_sim_main:42:117:66:19:20"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:20"] = {rtwname: "<S4>/sunsensor_body_processed"};
	this.rtwnameHashMap["<S5>/mag_body_meas_T"] = {sid: "adcs_sim_main:42:117:66:91"};
	this.sidHashMap["adcs_sim_main:42:117:66:91"] = {rtwname: "<S5>/mag_body_meas_T"};
	this.rtwnameHashMap["<S5>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:53"};
	this.sidHashMap["adcs_sim_main:42:117:66:53"] = {rtwname: "<S5>/Data Type Conversion"};
	this.rtwnameHashMap["<S5>/Demux"] = {sid: "adcs_sim_main:42:117:66:94"};
	this.sidHashMap["adcs_sim_main:42:117:66:94"] = {rtwname: "<S5>/Demux"};
	this.rtwnameHashMap["<S5>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:56"] = {rtwname: "<S5>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S5>/Mux"] = {sid: "adcs_sim_main:42:117:66:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:59"] = {rtwname: "<S5>/Mux"};
	this.rtwnameHashMap["<S5>/Product"] = {sid: "adcs_sim_main:42:117:66:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:60"] = {rtwname: "<S5>/Product"};
	this.rtwnameHashMap["<S5>/Product1"] = {sid: "adcs_sim_main:42:117:66:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:61"] = {rtwname: "<S5>/Product1"};
	this.rtwnameHashMap["<S5>/Sum"] = {sid: "adcs_sim_main:42:117:66:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:65"] = {rtwname: "<S5>/Sum"};
	this.rtwnameHashMap["<S5>/bias"] = {sid: "adcs_sim_main:42:117:66:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:70"] = {rtwname: "<S5>/bias"};
	this.rtwnameHashMap["<S5>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:71"] = {rtwname: "<S5>/process_matrix"};
	this.rtwnameHashMap["<S5>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:72"] = {rtwname: "<S5>/sensor2body"};
	this.rtwnameHashMap["<S5>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:93"};
	this.sidHashMap["adcs_sim_main:42:117:66:93"] = {rtwname: "<S5>/mag_body_processed_T"};
	this.rtwnameHashMap["<S6>/mag_body_meas_T"] = {sid: "adcs_sim_main:42:117:66:97:91"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:91"] = {rtwname: "<S6>/mag_body_meas_T"};
	this.rtwnameHashMap["<S6>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:97:53"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:53"] = {rtwname: "<S6>/Data Type Conversion"};
	this.rtwnameHashMap["<S6>/Demux"] = {sid: "adcs_sim_main:42:117:66:97:94"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:94"] = {rtwname: "<S6>/Demux"};
	this.rtwnameHashMap["<S6>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:117:66:97:56"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:56"] = {rtwname: "<S6>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S6>/Mux"] = {sid: "adcs_sim_main:42:117:66:97:59"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:59"] = {rtwname: "<S6>/Mux"};
	this.rtwnameHashMap["<S6>/Product"] = {sid: "adcs_sim_main:42:117:66:97:60"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:60"] = {rtwname: "<S6>/Product"};
	this.rtwnameHashMap["<S6>/Product1"] = {sid: "adcs_sim_main:42:117:66:97:61"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:61"] = {rtwname: "<S6>/Product1"};
	this.rtwnameHashMap["<S6>/Sum"] = {sid: "adcs_sim_main:42:117:66:97:65"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:65"] = {rtwname: "<S6>/Sum"};
	this.rtwnameHashMap["<S6>/bias"] = {sid: "adcs_sim_main:42:117:66:97:70"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:70"] = {rtwname: "<S6>/bias"};
	this.rtwnameHashMap["<S6>/process_matrix"] = {sid: "adcs_sim_main:42:117:66:97:71"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:71"] = {rtwname: "<S6>/process_matrix"};
	this.rtwnameHashMap["<S6>/sensor2body"] = {sid: "adcs_sim_main:42:117:66:97:72"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:72"] = {rtwname: "<S6>/sensor2body"};
	this.rtwnameHashMap["<S6>/mag_body_processed_T"] = {sid: "adcs_sim_main:42:117:66:97:93"};
	this.sidHashMap["adcs_sim_main:42:117:66:97:93"] = {rtwname: "<S6>/mag_body_processed_T"};
	this.rtwnameHashMap["<S7>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:197"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:197"] = {rtwname: "<S7>/alpha"};
	this.rtwnameHashMap["<S7>/beta"] = {sid: "adcs_sim_main:42:117:66:19:198"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:198"] = {rtwname: "<S7>/beta"};
	this.rtwnameHashMap["<S7>/ss_flag"] = {sid: "adcs_sim_main:42:117:66:19:199"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:199"] = {rtwname: "<S7>/ss_flag"};
	this.rtwnameHashMap["<S7>/Action Port"] = {sid: "adcs_sim_main:42:117:66:19:172"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:172"] = {rtwname: "<S7>/Action Port"};
	this.rtwnameHashMap["<S7>/Interval Test"] = {sid: "adcs_sim_main:42:117:66:19:200"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200"] = {rtwname: "<S7>/Interval Test"};
	this.rtwnameHashMap["<S7>/Interval Test1"] = {sid: "adcs_sim_main:42:117:66:19:201"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201"] = {rtwname: "<S7>/Interval Test1"};
	this.rtwnameHashMap["<S7>/Logical Operator"] = {sid: "adcs_sim_main:42:117:66:19:202"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:202"] = {rtwname: "<S7>/Logical Operator"};
	this.rtwnameHashMap["<S7>/Switch"] = {sid: "adcs_sim_main:42:117:66:19:203"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:203"] = {rtwname: "<S7>/Switch"};
	this.rtwnameHashMap["<S7>/Unit Delay"] = {sid: "adcs_sim_main:42:117:66:19:204"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:204"] = {rtwname: "<S7>/Unit Delay"};
	this.rtwnameHashMap["<S7>/ss_flag_out"] = {sid: "adcs_sim_main:42:117:66:19:173"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:173"] = {rtwname: "<S7>/ss_flag_out"};
	this.rtwnameHashMap["<S8>/ss_flag"] = {sid: "adcs_sim_main:42:117:66:19:164"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:164"] = {rtwname: "<S8>/ss_flag"};
	this.rtwnameHashMap["<S8>/Action Port"] = {sid: "adcs_sim_main:42:117:66:19:165"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:165"] = {rtwname: "<S8>/Action Port"};
	this.rtwnameHashMap["<S8>/ss_flag_out"] = {sid: "adcs_sim_main:42:117:66:19:166"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:166"] = {rtwname: "<S8>/ss_flag_out"};
	this.rtwnameHashMap["<S9>/alpha"] = {sid: "adcs_sim_main:42:117:66:19:122:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:2"] = {rtwname: "<S9>/alpha"};
	this.rtwnameHashMap["<S9>/beta"] = {sid: "adcs_sim_main:42:117:66:19:122:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:3"] = {rtwname: "<S9>/beta"};
	this.rtwnameHashMap["<S9>/Constant"] = {sid: "adcs_sim_main:42:117:66:19:122:32"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:32"] = {rtwname: "<S9>/Constant"};
	this.rtwnameHashMap["<S9>/Data Type Conversion"] = {sid: "adcs_sim_main:42:117:66:19:122:33"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:33"] = {rtwname: "<S9>/Data Type Conversion"};
	this.rtwnameHashMap["<S9>/Data Type Conversion1"] = {sid: "adcs_sim_main:42:117:66:19:122:34"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:34"] = {rtwname: "<S9>/Data Type Conversion1"};
	this.rtwnameHashMap["<S9>/Data Type Conversion2"] = {sid: "adcs_sim_main:42:117:66:19:122:35"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:35"] = {rtwname: "<S9>/Data Type Conversion2"};
	this.rtwnameHashMap["<S9>/Math Function"] = {sid: "adcs_sim_main:42:117:66:19:122:36"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:36"] = {rtwname: "<S9>/Math Function"};
	this.rtwnameHashMap["<S9>/Math Function1"] = {sid: "adcs_sim_main:42:117:66:19:122:37"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:37"] = {rtwname: "<S9>/Math Function1"};
	this.rtwnameHashMap["<S9>/Mux"] = {sid: "adcs_sim_main:42:117:66:19:122:38"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:38"] = {rtwname: "<S9>/Mux"};
	this.rtwnameHashMap["<S9>/Product"] = {sid: "adcs_sim_main:42:117:66:19:122:39"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:39"] = {rtwname: "<S9>/Product"};
	this.rtwnameHashMap["<S9>/Product1"] = {sid: "adcs_sim_main:42:117:66:19:122:40"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:40"] = {rtwname: "<S9>/Product1"};
	this.rtwnameHashMap["<S9>/Reciprocal Sqrt"] = {sid: "adcs_sim_main:42:117:66:19:122:41"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:41"] = {rtwname: "<S9>/Reciprocal Sqrt"};
	this.rtwnameHashMap["<S9>/Sum"] = {sid: "adcs_sim_main:42:117:66:19:122:42"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:42"] = {rtwname: "<S9>/Sum"};
	this.rtwnameHashMap["<S9>/Trigonometric Function"] = {sid: "adcs_sim_main:42:117:66:19:122:43"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:43"] = {rtwname: "<S9>/Trigonometric Function"};
	this.rtwnameHashMap["<S9>/Trigonometric Function1"] = {sid: "adcs_sim_main:42:117:66:19:122:44"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:44"] = {rtwname: "<S9>/Trigonometric Function1"};
	this.rtwnameHashMap["<S9>/deg2rad"] = {sid: "adcs_sim_main:42:117:66:19:122:45"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:45"] = {rtwname: "<S9>/deg2rad"};
	this.rtwnameHashMap["<S9>/deg2rad "] = {sid: "adcs_sim_main:42:117:66:19:122:46"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:46"] = {rtwname: "<S9>/deg2rad "};
	this.rtwnameHashMap["<S9>/sunsensor_unit_body"] = {sid: "adcs_sim_main:42:117:66:19:122:16"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:122:16"] = {rtwname: "<S9>/sunsensor_unit_body"};
	this.rtwnameHashMap["<S10>/u"] = {sid: "adcs_sim_main:42:117:66:19:200:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:1"] = {rtwname: "<S10>/u"};
	this.rtwnameHashMap["<S10>/AND"] = {sid: "adcs_sim_main:42:117:66:19:200:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:2"] = {rtwname: "<S10>/AND"};
	this.rtwnameHashMap["<S10>/FixPt Data Type Duplicate"] = {sid: "adcs_sim_main:42:117:66:19:200:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:3"] = {rtwname: "<S10>/FixPt Data Type Duplicate"};
	this.rtwnameHashMap["<S10>/Lower Limit"] = {sid: "adcs_sim_main:42:117:66:19:200:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:4"] = {rtwname: "<S10>/Lower Limit"};
	this.rtwnameHashMap["<S10>/Lower Test"] = {sid: "adcs_sim_main:42:117:66:19:200:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:5"] = {rtwname: "<S10>/Lower Test"};
	this.rtwnameHashMap["<S10>/Upper Limit"] = {sid: "adcs_sim_main:42:117:66:19:200:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:6"] = {rtwname: "<S10>/Upper Limit"};
	this.rtwnameHashMap["<S10>/Upper Test"] = {sid: "adcs_sim_main:42:117:66:19:200:7"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:7"] = {rtwname: "<S10>/Upper Test"};
	this.rtwnameHashMap["<S10>/y"] = {sid: "adcs_sim_main:42:117:66:19:200:8"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:200:8"] = {rtwname: "<S10>/y"};
	this.rtwnameHashMap["<S11>/u"] = {sid: "adcs_sim_main:42:117:66:19:201:1"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:1"] = {rtwname: "<S11>/u"};
	this.rtwnameHashMap["<S11>/AND"] = {sid: "adcs_sim_main:42:117:66:19:201:2"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:2"] = {rtwname: "<S11>/AND"};
	this.rtwnameHashMap["<S11>/FixPt Data Type Duplicate"] = {sid: "adcs_sim_main:42:117:66:19:201:3"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:3"] = {rtwname: "<S11>/FixPt Data Type Duplicate"};
	this.rtwnameHashMap["<S11>/Lower Limit"] = {sid: "adcs_sim_main:42:117:66:19:201:4"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:4"] = {rtwname: "<S11>/Lower Limit"};
	this.rtwnameHashMap["<S11>/Lower Test"] = {sid: "adcs_sim_main:42:117:66:19:201:5"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:5"] = {rtwname: "<S11>/Lower Test"};
	this.rtwnameHashMap["<S11>/Upper Limit"] = {sid: "adcs_sim_main:42:117:66:19:201:6"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:6"] = {rtwname: "<S11>/Upper Limit"};
	this.rtwnameHashMap["<S11>/Upper Test"] = {sid: "adcs_sim_main:42:117:66:19:201:7"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:7"] = {rtwname: "<S11>/Upper Test"};
	this.rtwnameHashMap["<S11>/y"] = {sid: "adcs_sim_main:42:117:66:19:201:8"};
	this.sidHashMap["adcs_sim_main:42:117:66:19:201:8"] = {rtwname: "<S11>/y"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
