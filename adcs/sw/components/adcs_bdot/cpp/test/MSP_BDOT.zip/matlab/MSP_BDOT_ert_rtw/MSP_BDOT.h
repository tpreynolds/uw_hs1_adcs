/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: MSP_BDOT.h
 *
 * Code generated for Simulink model 'MSP_BDOT'.
 *
 * Model version                  : 1.329
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Sat Apr  7 15:47:26 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->MSP430
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MSP_BDOT_h_
#define RTW_HEADER_MSP_BDOT_h_
#include <math.h>
#ifndef MSP_BDOT_COMMON_INCLUDES_
# define MSP_BDOT_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* MSP_BDOT_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (auto storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE[3];          /* '<S2>/Unit Delay' */
  real_T DiscreteTransferFcn_states[3];/* '<S2>/Discrete Transfer Fcn' */
  real_T UD_DSTATE[3];                 /* '<S3>/UD' */
  real_T RateTransition3_Buffer[2];    /* '<S2>/Rate Transition3' */
  int32_T clockTickCounter;            /* '<S1>/Pulse Generator' */
  int8_T RateTransition3_ActiveBufIdx; /* '<S2>/Rate Transition3' */
  boolean_T Relay_Mode;                /* '<S2>/Relay' */
} DW;

/* Constant parameters (auto storage) */
typedef struct {
  /* Expression: fsw_params.bdot.gain_matrix
   * Referenced by: '<S2>/gain matrix'
   */
  real_T gainmatrix_Value[9];

  /* Expression: fsw_params.sensor_processing.magnetometer.process_matrix
   * Referenced by: '<S4>/Constant1'
   */
  real_T Constant1_Value[9];
} ConstP;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T mag_vec_body_T[4];            /* '<Root>/mag_body_T_unprocessed' */
} ExtU;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  int8_T cmd_MAG_bdot[3];              /* '<Root>/cmd_MAG_bdot' */
  boolean_T tumble;                    /* '<Root>/tumble' */
} ExtY;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T * volatile errorStatus;
};

/* Block signals and states (auto storage) */
extern DW rtDW;

/* External inputs (root inport signals with auto storage) */
extern ExtU rtU;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY rtY;

/* Constant parameters (auto storage) */
extern const ConstP rtConstP;

/* Model entry point functions */
extern void MSP_BDOT_initialize(void);
extern void MSP_BDOT_step0(void);
extern void MSP_BDOT_step1(void);
extern void MSP_BDOT_terminate(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Data Type Duplicate' : Unused code path elimination
 * Block '<S2>/Rate Transition1' : Eliminated since input and output rates are identical
 * Block '<S2>/Rate Transition2' : Eliminated since input and output rates are identical
 * Block '<S2>/Rate Transition4' : Eliminated since input and output rates are identical
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('adcs_sim_main/Flightsoftware/MSP_BDOT')    - opens subsystem adcs_sim_main/Flightsoftware/MSP_BDOT
 * hilite_system('adcs_sim_main/Flightsoftware/MSP_BDOT/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'adcs_sim_main/Flightsoftware'
 * '<S1>'   : 'adcs_sim_main/Flightsoftware/MSP_BDOT'
 * '<S2>'   : 'adcs_sim_main/Flightsoftware/MSP_BDOT/bdot_controller_lib'
 * '<S3>'   : 'adcs_sim_main/Flightsoftware/MSP_BDOT/bdot_controller_lib/Discrete Derivative'
 * '<S4>'   : 'adcs_sim_main/Flightsoftware/MSP_BDOT/bdot_controller_lib/Signal Processing'
 */
#endif                                 /* RTW_HEADER_MSP_BDOT_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
