function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Constant */
	this.urlHashMap["adcs_sim_main:42:277:5:47"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:277:5:47";
	/* <S1>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:277:5:80"] = "bdot_controller_lib.c:232,275";
	/* <S1>/Data Type Conversion1 */
	this.urlHashMap["adcs_sim_main:42:277:5:89"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:277:5:89";
	/* <S1>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:277:5:32"] = "bdot_controller_lib.c:57,58,67,68,82,83,92,93,107,108,117,118,279,280,290,291,295,300,301&bdot_controller_lib.h:47";
	/* <S1>/Dot Product */
	this.urlHashMap["adcs_sim_main:42:277:5:84"] = "bdot_controller_lib.c:213";
	/* <S1>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:277:5:28"] = "bdot_controller_lib.c:133";
	/* <S1>/Logical
Operator1 */
	this.urlHashMap["adcs_sim_main:42:277:5:42"] = "bdot_controller_lib.c:51";
	/* <S1>/Multiport
Switch1 */
	this.urlHashMap["adcs_sim_main:42:277:5:33"] = "bdot_controller_lib.c:131,146";
	/* <S1>/Multiport
Switch2 */
	this.urlHashMap["adcs_sim_main:42:277:5:46"] = "bdot_controller_lib.c:148,210";
	/* <S1>/Product */
	this.urlHashMap["adcs_sim_main:42:277:5:60"] = "bdot_controller_lib.c:158,167";
	/* <S1>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:277:5:6"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:277:5:6";
	/* <S1>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:277:5:29"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:277:5:29";
	/* <S1>/Rate Transition3 */
	this.urlHashMap["adcs_sim_main:42:277:5:30"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:277:5:30";
	/* <S1>/Rate Transition4 */
	this.urlHashMap["adcs_sim_main:42:277:5:7"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:277:5:7";
	/* <S1>/Relay */
	this.urlHashMap["adcs_sim_main:42:277:5:88"] = "bdot_controller_lib.c:218,228&bdot_controller_lib.h:49";
	/* <S1>/Saturation1 */
	this.urlHashMap["adcs_sim_main:42:277:5:61"] = "bdot_controller_lib.c:169,178";
	/* <S1>/Saturation2 */
	this.urlHashMap["adcs_sim_main:42:277:5:62"] = "bdot_controller_lib.c:181,192";
	/* <S1>/Saturation3 */
	this.urlHashMap["adcs_sim_main:42:277:5:63"] = "bdot_controller_lib.c:195,206";
	/* <S1>/Sqrt */
	this.urlHashMap["adcs_sim_main:42:277:5:85"] = "bdot_controller_lib.c:212";
	/* <S1>/To DigVal1 */
	this.urlHashMap["adcs_sim_main:42:277:5:17"] = "bdot_controller_lib.c:149,182";
	/* <S1>/To DigVal2 */
	this.urlHashMap["adcs_sim_main:42:277:5:65"] = "bdot_controller_lib.c:150,196";
	/* <S1>/To DigVal3 */
	this.urlHashMap["adcs_sim_main:42:277:5:66"] = "bdot_controller_lib.c:151";
	/* <S1>/Unit Delay */
	this.urlHashMap["adcs_sim_main:42:277:5:45"] = "bdot_controller_lib.c:134,289&bdot_controller_lib.h:46";
	/* <S1>/gain matrix */
	this.urlHashMap["adcs_sim_main:42:277:5:64"] = "bdot_controller_lib.c:159&bdot_controller_lib.h:55&bdot_controller_lib_data.c:27";
	/* <S2>/Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:277:5:41:2"] = "msg=rtwMsg_reducedBlock&block=adcs_sim_main:42:277:5:41:2";
	/* <S2>/Diff */
	this.urlHashMap["adcs_sim_main:42:277:5:41:3"] = "bdot_controller_lib.c:66,71,91,96,116,121";
	/* <S2>/TSamp */
	this.urlHashMap["adcs_sim_main:42:277:5:41:4"] = "bdot_controller_lib.c:56,60,81,85,106,110";
	/* <S2>/UD */
	this.urlHashMap["adcs_sim_main:42:277:5:41:5"] = "bdot_controller_lib.c:69,75,94,100,119,125,299,303&bdot_controller_lib.h:48";
	/* <S3>/Constant */
	this.urlHashMap["adcs_sim_main:42:277:5:54"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:277:5:54";
	/* <S3>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:277:5:56"] = "bdot_controller_lib.c:278&bdot_controller_lib.h:60&bdot_controller_lib_data.c:32";
	/* <S3>/Product */
	this.urlHashMap["adcs_sim_main:42:277:5:55"] = "bdot_controller_lib.c:277";
	/* <S3>/Sum */
	this.urlHashMap["adcs_sim_main:42:277:5:53"] = "bdot_controller_lib.c:282";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "bdot_controller_lib"};
	this.sidHashMap["bdot_controller_lib"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:277:5"};
	this.sidHashMap["adcs_sim_main:42:277:5"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:277:5:41"};
	this.sidHashMap["adcs_sim_main:42:277:5:41"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:277:5:50"};
	this.sidHashMap["adcs_sim_main:42:277:5:50"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S1>/B_body_in_T"] = {sid: "adcs_sim_main:42:277:5:22"};
	this.sidHashMap["adcs_sim_main:42:277:5:22"] = {rtwname: "<S1>/B_body_in_T"};
	this.rtwnameHashMap["<S1>/B_meas_valid"] = {sid: "adcs_sim_main:42:277:5:25"};
	this.sidHashMap["adcs_sim_main:42:277:5:25"] = {rtwname: "<S1>/B_meas_valid"};
	this.rtwnameHashMap["<S1>/MT_on"] = {sid: "adcs_sim_main:42:277:5:27"};
	this.sidHashMap["adcs_sim_main:42:277:5:27"] = {rtwname: "<S1>/MT_on"};
	this.rtwnameHashMap["<S1>/Constant"] = {sid: "adcs_sim_main:42:277:5:47"};
	this.sidHashMap["adcs_sim_main:42:277:5:47"] = {rtwname: "<S1>/Constant"};
	this.rtwnameHashMap["<S1>/Data Type Conversion"] = {sid: "adcs_sim_main:42:277:5:80"};
	this.sidHashMap["adcs_sim_main:42:277:5:80"] = {rtwname: "<S1>/Data Type Conversion"};
	this.rtwnameHashMap["<S1>/Data Type Conversion1"] = {sid: "adcs_sim_main:42:277:5:89"};
	this.sidHashMap["adcs_sim_main:42:277:5:89"] = {rtwname: "<S1>/Data Type Conversion1"};
	this.rtwnameHashMap["<S1>/Demux"] = {sid: "adcs_sim_main:42:277:5:58"};
	this.sidHashMap["adcs_sim_main:42:277:5:58"] = {rtwname: "<S1>/Demux"};
	this.rtwnameHashMap["<S1>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:277:5:32"};
	this.sidHashMap["adcs_sim_main:42:277:5:32"] = {rtwname: "<S1>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S1>/Discrete Derivative"] = {sid: "adcs_sim_main:42:277:5:41"};
	this.sidHashMap["adcs_sim_main:42:277:5:41"] = {rtwname: "<S1>/Discrete Derivative"};
	this.rtwnameHashMap["<S1>/Dot Product"] = {sid: "adcs_sim_main:42:277:5:84"};
	this.sidHashMap["adcs_sim_main:42:277:5:84"] = {rtwname: "<S1>/Dot Product"};
	this.rtwnameHashMap["<S1>/Logical Operator"] = {sid: "adcs_sim_main:42:277:5:28"};
	this.sidHashMap["adcs_sim_main:42:277:5:28"] = {rtwname: "<S1>/Logical Operator"};
	this.rtwnameHashMap["<S1>/Logical Operator1"] = {sid: "adcs_sim_main:42:277:5:42"};
	this.sidHashMap["adcs_sim_main:42:277:5:42"] = {rtwname: "<S1>/Logical Operator1"};
	this.rtwnameHashMap["<S1>/Multiport Switch1"] = {sid: "adcs_sim_main:42:277:5:33"};
	this.sidHashMap["adcs_sim_main:42:277:5:33"] = {rtwname: "<S1>/Multiport Switch1"};
	this.rtwnameHashMap["<S1>/Multiport Switch2"] = {sid: "adcs_sim_main:42:277:5:46"};
	this.sidHashMap["adcs_sim_main:42:277:5:46"] = {rtwname: "<S1>/Multiport Switch2"};
	this.rtwnameHashMap["<S1>/Mux"] = {sid: "adcs_sim_main:42:277:5:59"};
	this.sidHashMap["adcs_sim_main:42:277:5:59"] = {rtwname: "<S1>/Mux"};
	this.rtwnameHashMap["<S1>/Product"] = {sid: "adcs_sim_main:42:277:5:60"};
	this.sidHashMap["adcs_sim_main:42:277:5:60"] = {rtwname: "<S1>/Product"};
	this.rtwnameHashMap["<S1>/Rate Transition1"] = {sid: "adcs_sim_main:42:277:5:6"};
	this.sidHashMap["adcs_sim_main:42:277:5:6"] = {rtwname: "<S1>/Rate Transition1"};
	this.rtwnameHashMap["<S1>/Rate Transition2"] = {sid: "adcs_sim_main:42:277:5:29"};
	this.sidHashMap["adcs_sim_main:42:277:5:29"] = {rtwname: "<S1>/Rate Transition2"};
	this.rtwnameHashMap["<S1>/Rate Transition3"] = {sid: "adcs_sim_main:42:277:5:30"};
	this.sidHashMap["adcs_sim_main:42:277:5:30"] = {rtwname: "<S1>/Rate Transition3"};
	this.rtwnameHashMap["<S1>/Rate Transition4"] = {sid: "adcs_sim_main:42:277:5:7"};
	this.sidHashMap["adcs_sim_main:42:277:5:7"] = {rtwname: "<S1>/Rate Transition4"};
	this.rtwnameHashMap["<S1>/Relay"] = {sid: "adcs_sim_main:42:277:5:88"};
	this.sidHashMap["adcs_sim_main:42:277:5:88"] = {rtwname: "<S1>/Relay"};
	this.rtwnameHashMap["<S1>/Saturation1"] = {sid: "adcs_sim_main:42:277:5:61"};
	this.sidHashMap["adcs_sim_main:42:277:5:61"] = {rtwname: "<S1>/Saturation1"};
	this.rtwnameHashMap["<S1>/Saturation2"] = {sid: "adcs_sim_main:42:277:5:62"};
	this.sidHashMap["adcs_sim_main:42:277:5:62"] = {rtwname: "<S1>/Saturation2"};
	this.rtwnameHashMap["<S1>/Saturation3"] = {sid: "adcs_sim_main:42:277:5:63"};
	this.sidHashMap["adcs_sim_main:42:277:5:63"] = {rtwname: "<S1>/Saturation3"};
	this.rtwnameHashMap["<S1>/Signal Processing"] = {sid: "adcs_sim_main:42:277:5:50"};
	this.sidHashMap["adcs_sim_main:42:277:5:50"] = {rtwname: "<S1>/Signal Processing"};
	this.rtwnameHashMap["<S1>/Sqrt"] = {sid: "adcs_sim_main:42:277:5:85"};
	this.sidHashMap["adcs_sim_main:42:277:5:85"] = {rtwname: "<S1>/Sqrt"};
	this.rtwnameHashMap["<S1>/To DigVal1"] = {sid: "adcs_sim_main:42:277:5:17"};
	this.sidHashMap["adcs_sim_main:42:277:5:17"] = {rtwname: "<S1>/To DigVal1"};
	this.rtwnameHashMap["<S1>/To DigVal2"] = {sid: "adcs_sim_main:42:277:5:65"};
	this.sidHashMap["adcs_sim_main:42:277:5:65"] = {rtwname: "<S1>/To DigVal2"};
	this.rtwnameHashMap["<S1>/To DigVal3"] = {sid: "adcs_sim_main:42:277:5:66"};
	this.sidHashMap["adcs_sim_main:42:277:5:66"] = {rtwname: "<S1>/To DigVal3"};
	this.rtwnameHashMap["<S1>/Unit Delay"] = {sid: "adcs_sim_main:42:277:5:45"};
	this.sidHashMap["adcs_sim_main:42:277:5:45"] = {rtwname: "<S1>/Unit Delay"};
	this.rtwnameHashMap["<S1>/gain matrix"] = {sid: "adcs_sim_main:42:277:5:64"};
	this.sidHashMap["adcs_sim_main:42:277:5:64"] = {rtwname: "<S1>/gain matrix"};
	this.rtwnameHashMap["<S1>/Dig_val"] = {sid: "adcs_sim_main:42:277:5:23"};
	this.sidHashMap["adcs_sim_main:42:277:5:23"] = {rtwname: "<S1>/Dig_val"};
	this.rtwnameHashMap["<S1>/tumble"] = {sid: "adcs_sim_main:42:277:5:87"};
	this.sidHashMap["adcs_sim_main:42:277:5:87"] = {rtwname: "<S1>/tumble"};
	this.rtwnameHashMap["<S2>/U"] = {sid: "adcs_sim_main:42:277:5:41:1"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:1"] = {rtwname: "<S2>/U"};
	this.rtwnameHashMap["<S2>/Data Type Duplicate"] = {sid: "adcs_sim_main:42:277:5:41:2"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:2"] = {rtwname: "<S2>/Data Type Duplicate"};
	this.rtwnameHashMap["<S2>/Diff"] = {sid: "adcs_sim_main:42:277:5:41:3"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:3"] = {rtwname: "<S2>/Diff"};
	this.rtwnameHashMap["<S2>/TSamp"] = {sid: "adcs_sim_main:42:277:5:41:4"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:4"] = {rtwname: "<S2>/TSamp"};
	this.rtwnameHashMap["<S2>/UD"] = {sid: "adcs_sim_main:42:277:5:41:5"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:5"] = {rtwname: "<S2>/UD"};
	this.rtwnameHashMap["<S2>/Y"] = {sid: "adcs_sim_main:42:277:5:41:6"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:6"] = {rtwname: "<S2>/Y"};
	this.rtwnameHashMap["<S3>/b_in_T"] = {sid: "adcs_sim_main:42:277:5:51"};
	this.sidHashMap["adcs_sim_main:42:277:5:51"] = {rtwname: "<S3>/b_in_T"};
	this.rtwnameHashMap["<S3>/Constant"] = {sid: "adcs_sim_main:42:277:5:54"};
	this.sidHashMap["adcs_sim_main:42:277:5:54"] = {rtwname: "<S3>/Constant"};
	this.rtwnameHashMap["<S3>/Constant1"] = {sid: "adcs_sim_main:42:277:5:56"};
	this.sidHashMap["adcs_sim_main:42:277:5:56"] = {rtwname: "<S3>/Constant1"};
	this.rtwnameHashMap["<S3>/Product"] = {sid: "adcs_sim_main:42:277:5:55"};
	this.sidHashMap["adcs_sim_main:42:277:5:55"] = {rtwname: "<S3>/Product"};
	this.rtwnameHashMap["<S3>/Sum"] = {sid: "adcs_sim_main:42:277:5:53"};
	this.sidHashMap["adcs_sim_main:42:277:5:53"] = {rtwname: "<S3>/Sum"};
	this.rtwnameHashMap["<S3>/b_out_T"] = {sid: "adcs_sim_main:42:277:5:52"};
	this.sidHashMap["adcs_sim_main:42:277:5:52"] = {rtwname: "<S3>/b_out_T"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
